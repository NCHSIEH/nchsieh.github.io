"""One-hour-ahead shift forecasts. Python 3.9+, standard library only."""
import argparse
import csv
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics as stats
from reports import weekly_report

HERE = Path(__file__).resolve().parent
TZ = timezone(timedelta(hours=8))
HOUR = timedelta(hours=1)
WEEK = timedelta(days=7)

def read(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def stamp(value):
    v = datetime.fromisoformat(value)
    if v.tzinfo is None:
        raise ValueError("timestamp requires an explicit UTC offset")
    return v.astimezone(TZ)

def write_table(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def assemble(folder):
    counts, visits, grid = Counter(), {}, {}
    for row in read(folder/'coverage.csv'):
        t, ready = stamp(row['shift_start']), stamp(row['finalized_at'])
        status = row['status']
        if t in grid or t.hour not in (0,8,16) or any((t.minute,t.second,t.microsecond)):
            raise ValueError(f"duplicate or invalid shift start {t}")
        if status not in ('complete','partial','offline') or ready < t+8*HOUR:
            raise ValueError(f"invalid coverage/finalization at {t}")
        grid[t] = (status,ready)
    times = sorted(grid)
    if len(times)!=420 or times[0].weekday()!=0 or times[0].hour!=0 or any(b-a != 8*HOUR for a,b in zip(times,times[1:])):
        raise ValueError("protocol requires a continuous 20-week grid from Monday 00:00")
    duplicates = 0
    for row in read(folder/'arrivals.csv'):
        vid, at = row['visit_id'].strip(), stamp(row['arrived_at'])
        if not vid or (vid in visits and visits[vid]!=at):
            raise ValueError(f"empty ID or conflicting arrival for {vid}")
        if vid in visits:
            duplicates += 1
            continue
        visits[vid] = at
        t = at.replace(hour=at.hour//8*8,minute=0,second=0,microsecond=0)
        if t not in grid:
            raise ValueError(f"time outside registered observation period {at}")
        counts[t] += 1
    shifts = {}
    for t in times:
        status, ready = grid[t]
        shifts[t] = dict(t=t, status=status, ready=ready, seen=counts[t],
                         y=counts[t] if status=='complete' else None)
    return shifts, dict(raw=len(visits)+duplicates,unique=len(visits),duplicates=duplicates)

def forecast(t, shifts, minimum):
    issue = t-HOUR
    hist = []
    for lag in range(1,9):
        r = shifts.get(t-lag*WEEK)
        if r and r['y'] is not None and r['ready'] <= issue:
            hist.append((lag,r['y']))
    recent = [y for k,y in hist if k<=4]
    base = stats.median(recent) if len(recent)>=minimum else None
    trend = None
    if len(hist)>=4:
        xs, ys = zip(*hist)
        mx, my = stats.mean(xs), stats.mean(ys)
        slope = math.fsum((x-mx)*(y-my) for x,y in hist)/math.fsum((x-mx)**2 for x in xs)
        trend = max(0,my-slope*mx)
    return base,trend,hist

def summary(rows, peak):
    common = [r for r in rows if r['y'] is not None and r['base'] is not None and r['trend'] is not None]
    out = dict(planned=len(rows),observed=sum(r['y'] is not None for r in rows),
               base_issued=sum(r['base'] is not None for r in rows),
               trend_issued=sum(r['trend'] is not None for r in rows),paired=len(common))
    for method in ('base','trend'):
        errors=[r[method]-r['y'] for r in common]
        high=[r for r in common if r['y']>=peak]
        out[method]=dict(mae=stats.mean(map(abs,errors)) if errors else None,
                         bias=stats.mean(errors) if errors else None,
                         under=sum(r[method]<r['y'] for r in high),peaks=len(high))
    return out

def run(folder, output, minimum):
    shifts,audit=assemble(folder)
    start=min(shifts)
    lock=start+12*WEEK
    history=sorted(r['y'] for r in shifts.values() if r['t']<lock and r['ready']<=lock-HOUR and r['y'] is not None)
    if not history: raise ValueError("no finalized development targets for peak threshold")
    peak=history[math.ceil(.9*len(history))-1]
    rows=[]
    for t,s in shifts.items():
        base,trend,hist=forecast(t,shifts,minimum)
        week=(t-start).days//7+1
        phase='warmup' if week<=8 else ('development' if week<=12 else 'test')
        rows.append(dict(shift_start=t.isoformat(),issue=(t-HOUR).isoformat(),week=week,phase=phase,
                         status=s['status'],finalized_at=s['ready'].isoformat(),seen=s['seen'],y=s['y'],
                         base=base,trend=trend,history='|'.join(f'{k}:{y}' for k,y in hist)))
    test=[r for r in rows if r['phase']=='test']
    per_week=[summary([r for r in test if r['week']==w],peak) for w in range(13,21)]
    paired=[r for r in test if all(r[k] is not None for k in ('y','base','trend'))]
    blocks=[[abs(r['trend']-r['y'])-abs(r['base']-r['y']) for r in paired if r['week']==w] for w in range(13,21)]
    if not all(blocks):raise ValueError("at least one paired forecast is required each test week")
    rng=random.Random(2208)
    reps=[]
    for _ in range(4000):
        sample=rng.choices(blocks,k=8)
        reps.append(math.fsum(math.fsum(block) for block in sample)/sum(map(len,sample)))
    reps.sort()
    result=dict(audit=audit,peak=peak,peak_development_n=len(history),minimum=minimum,
                test=summary(test,peak),weeks=per_week,development=summary([r for r in rows if r['phase']=='development'],peak),
                delta=stats.mean(x for block in blocks for x in block),
                ci=[reps[math.ceil(.025*len(reps))-1],reps[math.ceil(.975*len(reps))-1]],
                sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (folder/'coverage.csv',folder/'arrivals.csv')})
    output.mkdir(parents=True,exist_ok=True)
    write_table(output/'shifts.csv',rows)
    weekly_report(output,per_week)
    (output/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,default=HERE/'data')
    parser.add_argument('--out',type=Path,default=HERE/'results')
    parser.add_argument('--min-history',type=int,choices=(3,4),default=3)
    args=parser.parse_args()
    res=run(args.data,args.out,args.min_history)
    print(json.dumps({k:res[k] for k in ('audit','peak','test','delta','ci')},indent=2))


