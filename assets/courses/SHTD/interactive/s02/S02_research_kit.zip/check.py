"""Independently replay packaged sources, frozen results, and as-of boundary cases."""
import csv
from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import datetime, timedelta
import math
import sys
from analyze import assemble, forecast, run
from generate import generate
from model_lab import run as run_model_lab

here=Path(__file__).resolve().parent
with TemporaryDirectory() as temp:
    tmp=Path(temp)
    generate(tmp/'raw')
    for name in ('arrivals.csv','coverage.csv'):
        assert (here/'data'/name).read_bytes()==(tmp/'raw'/name).read_bytes(), name
    primary=run(here/'data',tmp/'results',3)
    for file in (here/'expected').iterdir():
        assert file.read_text(encoding='utf-8-sig')==(tmp/'results'/file.name).read_text(encoding='utf-8-sig'),file.name
    strict=run(here/'data',tmp/'strict',4)
    estimates, case, metrics = run_model_lab(here/'data',tmp/'models')
    assert [r['lag'] for r in case if r['eligible']]==[1,2,3,4,5,7,8]
    assert sum(r['xy'] for r in case if r['eligible'])==825
    assert math.isclose(estimates[1]['poisson8'],185/7)
    assert len(estimates)==168 and metrics[2]['n']==160
    assert math.isclose(metrics[2]['mae'],5.030543154761904)
    for f in (here/'model_expected').glob('*.csv'):
        assert f.read_text(encoding='utf-8-sig')==(tmp/'models'/f.name).read_text(encoding='utf-8-sig'),f.name
    assert primary['test']['paired']==160 and strict['test']['paired']==146
    assert math.isclose(primary['test']['base']['mae'],4.171875)
    s,_=assemble(here/'data')
    t=datetime.fromisoformat('2025-03-31T08:00:00+08:00')
    first=forecast(t,s,3)
    assert first[0]==24.5 and s[t]['y']==22
    assert s[datetime.fromisoformat('2025-04-19T08:00:00+08:00')]['y']==0
    assert all(r['y'] is None for r in s.values() if r['status']!='complete')
    copy={k:dict(v) for k,v in s.items()}
    for k,v in copy.items():
        if k>=t:v['y']=9999
    assert forecast(t,copy,3)==first
    delayed=t-timedelta(weeks=1)
    copy[delayed]['ready']=t
    assert 1 not in dict(forecast(t,copy,3)[2])
print('PASS: data regeneration, frozen outputs, true zero, incomplete labels, future and late data, sensitivity.',sys.version.split()[0])

