"""Weekly results table and a standalone chart, no external dependencies."""
import csv

def weekly_report(folder, weeks):
    labels = [(i+13, w['paired'], w['base']['mae'], w['trend']['mae']) for i,w in enumerate(weeks)]
    with (folder/'weekly.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f)
        w.writerow(['week','paired','base_mae','trend_mae'])
        w.writerows(labels)
    hi=max(1, int(max(max(row[2:]) for row in labels))+1)
    x=lambda i: 72+i*77
    y=lambda v: 256-v*190/hi
    svg=['<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="title" viewBox="0 0 680 320"><title id="title">合成測試期逐週平均絕對誤差</title><rect width="680" height="320" fill="#fff"/><g font-family="sans-serif" fill="#182f43" font-size="14"><text x="20" y="25">MAE（人次／班）</text><text x="300" y="25" fill="#165e77">● 四週中位數</text><text x="475" y="25" fill="#a84825">◆ 八週趨勢</text>']
    for value in range(0,hi+1):
        svg.append(f'<path d="M68 {y(value)}h553" stroke="#dee4e7"/><text x="54" y="{y(value)+4}">{value}</text>')
    for col,color in ((2,'#165e77'),(3,'#a84825')):
        points=' '.join(f'{x(i)},{y(row[col]):.2f}' for i,row in enumerate(labels))
        svg.append(f'<polyline points="{points}" stroke="{color}" stroke-width="2.5" fill="none"/>')
        for i,row in enumerate(labels):
            xx,yy=x(i),y(row[col])
            if col==2:svg.append(f'<circle cx="{xx}" cy="{yy}" r="4" fill="{color}"/>')
            else:svg.append(f'<path d="M{xx} {yy-5}l5 5 -5 5 -5 -5z" fill="{color}"/>')
    for i,row in enumerate(labels):svg.append(f'<text x="{x(i)}" y="280" text-anchor="middle">{row[0]}</text>')
    svg.append('<text x="335" y="308" text-anchor="middle">研究週次</text></g></svg>')
    (folder/'weekly.svg').write_text(''.join(svg),encoding='utf-8')

