"""Additional S2 worked estimates. Run from an extracted research kit (Python 3.9+)."""
import argparse
import math
from pathlib import Path
from statistics import mean, median
from datetime import timedelta
from analyze import assemble, forecast, write_table, WEEK, HOUR

HERE = Path(__file__).resolve().parent

def run(data, out):
    shifts, _ = assemble(data)
    target = min(shifts) + 12*WEEK + 8*HOUR
    test_start = min(shifts) + 12*WEEK
    estimates, case = [], []
    for t, shift in shifts.items():
        if t < test_start:
            continue
        base, trend, history = forecast(t,shifts,3)
        values = dict(history)
        n = len(values)
        counts = sum(values.values())
        hours = 8*n
        rate_model = 8 * counts / hours if n>=4 else None
        if t == target:
            for x in range(1,9):
                p = shifts[t-x*WEEK]
                y = values.get(x)
                case.append(dict(lag=x,date=p['t'].date(),status=p['status'],seen=p['seen'],
                                 eligible=int(y is not None),y=y,xy=x*y if y is not None else None,
                                 x2=x*x if y is not None else None))
        estimates.append(dict(shift_start=t.isoformat(),week=1+(t-min(shifts)).days//7,
                              hour=t.hour,actual=shift['y'],history_n=n,history_sum=counts,
                              exposure_hours=hours,median4=base,linear8=trend,poisson8=rate_model))
    out.mkdir(exist_ok=True,parents=True)
    write_table(out/'case_calculation.csv',case)
    write_table(out/'model_estimates.csv',estimates)
    metric_rows=[]
    paired=[r for r in estimates if all(r[k] is not None for k in ('actual','median4','linear8','poisson8'))]
    for label,group in [('all',paired)]+[(str(h),[r for r in paired if r['hour']==h]) for h in (0,8,16)]:
        for key in ('median4','linear8','poisson8'):
            errors=[r[key]-r['actual'] for r in group]
            metric_rows.append(dict(hour=label,model=key,n=len(group),mae=mean(map(abs,errors)),
                                    bias=mean(errors),rmse=math.sqrt(mean(e*e for e in errors))))
    write_table(out/'model_metrics.csv',metric_rows)
    return estimates, case, metric_rows

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,default=HERE/'data')
    parser.add_argument('--out',type=Path,default=HERE/'model_results')
    args=parser.parse_args()
    _,case,metrics=run(args.data,args.out)
    print('Eligible case rows:', sum(r['eligible'] for r in case))
    for r in metrics[:3]:
        print(r['model'], 'n=',r['n'],'MAE=',round(r['mae'],3),'RMSE=',round(r['rmse'],3))

