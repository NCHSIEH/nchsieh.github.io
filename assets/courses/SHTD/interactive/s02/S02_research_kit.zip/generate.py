"""Generate this fictional single-site dataset with Python 3.9+."""
import csv
import math
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
import argparse

def write(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(fields)
        w.writerows(rows)

def generate(folder):
    folder.mkdir(parents=True, exist_ok=True)
    rng = random.Random(2207)
    start = datetime(2025, 1, 6, tzinfo=timezone(timedelta(hours=8)))
    arrivals, coverage = [], []
    for i in range(420):
        at = start + timedelta(hours=8*i)
        day, band = divmod(i, 3)
        mean = [10, 24, 19][band] + [4,1,0,0,2,3,-1][at.weekday()]
        mean += 3 * math.sin(day/17) + (4 if day >= 86 else 0)
        n = max(1, round(rng.gauss(mean, 3.5)))
        status = "partial" if i in {37,127,210,231,285,307,369} else "complete"
        if i in {56,201,312}: status = "offline"
        if i in {61,310}: n = 0
        seen = n if status == "complete" else (n//2 if status == "partial" else 0)
        release = at + timedelta(hours=8,minutes=30)
        if i in {168,252,327}: release += timedelta(days=8)
        coverage.append([at.isoformat(),status,release.isoformat()])
        for j in range(seen):
            instant = at + timedelta(seconds=0 if j == 0 else rng.randrange(1,28800))
            arrivals.append([f"E{i:03d}-{j:03d}",instant.isoformat()])
    arrivals += [arrivals[i][:] for i in (5,90,152,320,602,880)]
    rng.shuffle(arrivals)
    write(folder/'arrivals.csv', ['visit_id','arrived_at'], arrivals)
    write(folder/'coverage.csv', ['shift_start','status','finalized_at'], coverage)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent/'regenerated')
    generate(parser.parse_args().out)

