# -*- coding: utf-8 -*-
"""Generate deterministic synthetic datasets for S3 (EMS Dynamic Staging & MCI Command Optimization).
Python 3.9+, standard library only. Fixed seed = 3309.
"""
import argparse
import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
import random

TZ = timezone(timedelta(hours=8))

# 12 需求分區：(zone_id, name, zone_type, x_km, y_km, base_day_rate_12h, base_night_rate_12h)
# 都會醫療網橫跨約 20 km × 15 km，單靠 4 輛救護車無法同時於 8 分鐘內涵蓋全部 12 區
ZONES = [
    ("Z01", "火車站前商圈",   "商業核心",  2.2, 12.2, 4.6, 1.1),
    ("Z02", "市政金融中心",   "商業核心",  6.4, 12.5, 5.0, 1.0),
    ("Z03", "科技園區北側",   "商業辦公", 11.8, 12.6, 4.3, 0.9),
    ("Z04", "大學醫療園區",   "文教商業",  7.0,  8.6, 3.3, 1.5),
    ("Z05", "松柏高齡國宅",   "高齡住宅",  2.4,  2.8, 1.4, 4.4),
    ("Z06", "溪南新市鎮",     "密集住宅",  6.6,  2.4, 1.6, 4.7),
    ("Z07", "安康老舊社區",   "高齡住宅", 12.6,  2.6, 1.5, 4.2),
    ("Z08", "東湖住宅群",     "密集住宅", 16.4,  4.0, 1.3, 3.6),
    ("Z09", "臨港石化工業區", "工業樞紐", 16.0, 11.8, 3.1, 1.5),  # 災時氣爆震央
    ("Z10", "國道交流道物流區","工業樞紐", 12.2,  8.2, 2.7, 1.7),
    ("Z11", "西濱漁港聚落",   "郊區聚落",  0.5,  7.5, 0.9, 0.9),
    ("Z12", "東山坡地社區",   "郊區聚落", 19.2,  8.8, 0.8, 1.0),
]

# 6 候選救護駐點：(station_id, name, x_km, y_km, static_default)
# 現行歷史靜態駐點：S1, S2, S3, S5（4 車全集中在北側與中區，導致南區/東南高齡住宅夜間涵蓋嚴重不足！）
STATIONS = [
    ("S1", "中正分隊（站前）",  2.8, 11.6, 1),
    ("S2", "市府分隊（金融）",  6.8, 11.4, 1),
    ("S3", "科園分隊（東北）", 13.6, 11.2, 1),
    ("S4", "溪南分隊（西南）",  4.6,  3.0, 0),
    ("S5", "仁愛分隊（中央）",  9.2,  7.6, 1),
    ("S6", "安康分隊（東南）", 14.4,  3.4, 0),
]

# 4 家急救責任醫院（災難 MCI 自 Z09 臨港石化工業區後送）：
# (hosp_id, name, level, drive_min_from_Z09, red_cap, yellow_cap, can_trauma_surgery)
HOSPITALS = [
    ("H1", "北城醫學中心", "重度級急救責任醫院", 16.0, 8, 12, 1),
    ("H2", "東區區域醫院", "中度級（燒燙傷專責）", 12.0, 5, 10, 1),
    ("H3", "南區區域醫院", "中度級急救責任醫院", 7.0,  4, 10, 1),
    ("H4", "西區地區醫院", "一般級（無重度開刀房）", 9.0, 0, 12, 0),
]


def write_csv(path, header, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writeheader() if hasattr(w, "writeheader") else w.writerow(header)


def save_table(path, header, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def travel_minutes(sx, sy, zx, zy, band):
    """計算救護車行駛分鐘數：路網距離 + 出勤準備 1.5 分鐘；日間商業區塞車係數較高"""
    euclid = ((sx - zx) ** 2 + (sy - zy) ** 2) ** 0.5
    road_km = 1.22 * euclid
    speed_km_min = 0.78 if band == "day" else 0.90  # 日間約 46.8 km/h，夜間救護鳴笛約 54 km/h
    congestion = 0.8 if (band == "day" and zy >= 8.0 and zx <= 13.0) else 0.0
    return round(1.5 + road_km / speed_km_min + congestion, 1)


def poisson_draw(rng, lam):
    L = pow(2.718281828459045, -lam)
    k = 0
    p = 1.0
    while p > L:
        k += 1
        p *= rng.random()
    return k - 1


def generate(folder: Path):
    folder.mkdir(parents=True, exist_ok=True)
    rng = random.Random(3309)

    # 1. 區域與駐點路網時間矩陣 stations_zones.csv
    sz_rows = []
    for sid, sname, sx, sy, s_def in STATIONS:
        for zid, zname, ztype, zx, zy, _, _ in ZONES:
            t_day = travel_minutes(sx, sy, zx, zy, "day")
            t_night = travel_minutes(sx, sy, zx, zy, "night")
            sz_rows.append([
                sid, sname, s_def, zid, zname, ztype,
                t_day, int(t_day <= 8.0), t_night, int(t_night <= 8.0)
            ])
    save_table(
        folder / "travel_matrix.csv",
        ["station_id", "station_name", "static_default", "zone_id", "zone_name", "zone_type",
         "day_min", "day_cov8", "night_min", "night_cov8"],
        sz_rows,
    )

    # 2. 16 週 119 救護出勤事件表 ems_calls.csv（W1–W8 訓練期，W9–W16 獨立測試期）
    # 每日 2 班段：day (08:00-20:00), night (20:00-翌日08:00)，共 112 天 × 2 = 224 班段
    start = datetime(2025, 2, 3, 8, 0, tzinfo=TZ)  # 週一 08:00 起算
    calls = []
    shift_log = []
    seq = 1
    for idx in range(224):
        b_start = start + timedelta(hours=12 * idx)
        week = idx // 14 + 1
        band = "day" if b_start.hour == 8 else "night"
        phase = "train" if week <= 8 else "test"
        # 模擬 3 個班段發生系統局部維護（不能當完整暴露時數）
        sys_status = "partial" if idx in (29, 105, 163) else "complete"
        shift_log.append([b_start.isoformat(), week, band, phase, sys_status, 12 if sys_status == "complete" else 6])

        for zid, _, _, _, _, r_day, r_night in ZONES:
            lam = r_day if band == "day" else r_night
            # 週末微調與緩慢季節波動
            if b_start.weekday() >= 5 and band == "day" and zid in ("Z01", "Z02", "Z03"):
                lam *= 0.82
            if week >= 9 and band == "night" and zid in ("Z05", "Z06", "Z07", "Z08"):
                lam *= 1.10  # 測試期入春溫差大，夜間高齡住宅呼救微增 10%
            if sys_status == "partial":
                lam *= 0.5
            n_calls = poisson_draw(rng, lam)
            for _ in range(n_calls):
                sec = rng.randrange(0, 12 * 3600)
                t_call = b_start + timedelta(seconds=sec)
                calls.append([f"C25-{seq:05d}", t_call.isoformat(), zid, "dispatched"])
                seq += 1

    # 加入真實世界資料瑕疵：8 筆報案後民眾自行取消 (cancelled)、5 筆 GPS 缺分區 (missing_zone)、4 筆重複匯出重送
    for k_idx in (12, 85, 190, 340, 510, 720, 950, 1180):
        if k_idx < len(calls):
            calls[k_idx][3] = "cancelled"
    for k_idx in (45, 260, 615, 890, 1105):
        if k_idx < len(calls):
            calls[k_idx][2] = ""
    for k_idx in (20, 150, 480, 810):
        if k_idx < len(calls):
            calls.append(calls[k_idx][:])

    rng.shuffle(calls)
    save_table(folder / "ems_calls.csv", ["call_id", "call_time", "zone_id", "call_status"], calls)
    save_table(folder / "ems_shifts.csv", ["band_start", "week", "band", "phase", "sys_status", "exposure_h"], shift_log)

    # 3. 災難大量傷病患 (MCI) 醫院容量表與 48 名傷患檢傷清單
    save_table(
        folder / "mci_hospitals.csv",
        ["hospital_id", "hospital_name", "level", "drive_min_from_Z09", "red_capacity", "yellow_capacity", "trauma_surgery"],
        [list(h) for h in HOSPITALS],
    )

    patients = []
    # 14 Red (Immediate), 20 Yellow (Delayed), 14 Green (Minor) = 48 patients at Z09
    specs = [("Red", 14, "極危險（立即復甦手術）", 3.0),
             ("Yellow", 20, "危險（需急診處置觀察）", 1.0),
             ("Green", 14, "輕傷（可行走／集中衛教）", 0.2)]
    p_no = 1
    for tag, cnt, desc, w_risk in specs:
        for _ in range(cnt):
            rr = rng.randint(31, 38) if tag == "Red" else (rng.randint(20, 28) if tag == "Yellow" else rng.randint(14, 20))
            sbp = rng.randint(72, 88) if tag == "Red" else (rng.randint(96, 128) if tag == "Yellow" else rng.randint(110, 136))
            patients.append([f"MCI-{p_no:02d}", "Z09", tag, desc, rr, sbp, w_risk])
            p_no += 1
    save_table(
        folder / "mci_patients.csv",
        ["patient_id", "incident_zone", "triage_tag", "clinical_desc", "resp_rate", "systolic_bp", "priority_weight"],
        patients,
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "data")
    generate(p.parse_args().out)
    print("Generated S3 synthetic datasets successfully.")
