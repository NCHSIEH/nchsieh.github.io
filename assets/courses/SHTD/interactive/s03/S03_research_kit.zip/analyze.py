# -*- coding: utf-8 -*-
"""Part A & Part B Optimization & Backtesting Engine for S3.
Python 3.9+, standard library only (zero pip dependencies).
1. Cleans & audits 119 EMS calls (deduplication, cancelled, missing zone, partial exposure).
2. Estimates Day/Night Poisson zone arrival rates on Train weeks (W1-W8) ONLY.
3. Solves Maximal Covering Location Problem (MCLP, K=4 of 6 stations) via exact enumeration & greedy heuristic.
4. Evaluates Static vs Dynamic Staging on Hold-out Test weeks (W9-W16) with week-clustered bootstrap 95% CI.
5. Solves Disaster MCI Forward Command Post (10 staff bottleneck allocation) & Multi-Hospital Surge Dispatch.
"""
import argparse
import csv
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import statistics as stats

HERE = Path(__file__).resolve().parent
TZ = timezone(timedelta(hours=8))


def read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def audit_and_estimate_ems(data_dir: Path, k_ambulances: int = 4, tau_min: float = 8.0):
    shifts_raw = read_csv(data_dir / "ems_shifts.csv")
    calls_raw = read_csv(data_dir / "ems_calls.csv")
    matrix_raw = read_csv(data_dir / "travel_matrix.csv")

    # 建立路網矩陣
    stations = []
    static_set = set()
    zones = []
    t_mat = {}  # (band, sid, zid) -> minutes
    for r in matrix_raw:
        sid, zid = r["station_id"], r["zone_id"]
        if sid not in stations:
            stations.append(sid)
        if int(r["static_default"]) == 1:
            static_set.add(sid)
        if zid not in zones:
            zones.append(zid)
        t_mat[("day", sid, zid)] = float(r["day_min"])
        t_mat[("night", sid, zid)] = float(r["night_min"])

    static_set = set(sorted(static_set)[:k_ambulances])
    # 排程主表索引
    shift_map = {}
    start_dt = datetime.fromisoformat(shifts_raw[0]["band_start"]).astimezone(TZ)
    for r in shifts_raw:
        dt = datetime.fromisoformat(r["band_start"]).astimezone(TZ)
        shift_map[dt] = {
            "dt": dt,
            "week": int(r["week"]),
            "band": r["band"],
            "phase": r["phase"],
            "sys_status": r["sys_status"],
            "exposure_h": int(r["exposure_h"]),
        }

    # 事件去重與清理稽核
    seen_ids = {}
    dup_count = 0
    cancelled_count = 0
    missing_zone_count = 0
    valid_calls = []

    for r in calls_raw:
        cid = r["call_id"].strip()
        ts = datetime.fromisoformat(r["call_time"]).astimezone(TZ)
        zid = r["zone_id"].strip()
        st = r["call_status"].strip()
        sig = (cid, ts.isoformat(), zid, st)
        if cid in seen_ids:
            if seen_ids[cid] != sig:
                raise ValueError(f"Conflicting duplicate call_id: {cid}")
            dup_count += 1
            continue
        seen_ids[cid] = sig
        if st == "cancelled":
            cancelled_count += 1
            continue
        if not zid or zid not in zones:
            missing_zone_count += 1
            continue
        idx = int((ts - start_dt).total_seconds() // (12 * 3600))
        b_dt = start_dt + timedelta(hours=12 * idx)
        if b_dt not in shift_map:
            raise ValueError(f"Call outside study window: {cid}")
        valid_calls.append({"call_id": cid, "dt": ts, "band_dt": b_dt, "zone_id": zid, **shift_map[b_dt]})

    audit = {
        "raw_rows": len(calls_raw),
        "duplicates_removed": dup_count,
        "unique_records": len(calls_raw) - dup_count,
        "cancelled_excluded": cancelled_count,
        "missing_zone_excluded": missing_zone_count,
        "valid_dispatched_calls": len(valid_calls),
        "total_shifts": len(shifts_raw),
        "complete_shifts": sum(s["sys_status"] == "complete" for s in shift_map.values()),
        "partial_shifts": sum(s["sys_status"] == "partial" for s in shift_map.values()),
    }

    # 僅用 W1–W8 且 sys_status == 'complete' 之完整班段估計各分區日/夜每 12h 呼救率
    train_complete = [s for s in shift_map.values() if s["phase"] == "train" and s["sys_status"] == "complete"]
    exp_bands = Counter(s["band"] for s in train_complete)  # 完整 12h 班數
    train_counts = Counter(
        (c["band"], c["zone_id"]) for c in valid_calls if c["phase"] == "train" and c["sys_status"] == "complete"
    )

    zone_rates = []
    lam_hat = {}
    for zid in zones:
        zname = next(r["zone_name"] for r in matrix_raw if r["zone_id"] == zid)
        ztype = next(r["zone_type"] for r in matrix_raw if r["zone_id"] == zid)
        day_c = train_counts[("day", zid)]
        night_c = train_counts[("night", zid)]
        r_day = day_c / exp_bands["day"]
        r_night = night_c / exp_bands["night"]
        lam_hat[("day", zid)] = r_day
        lam_hat[("night", zid)] = r_night
        zone_rates.append({
            "zone_id": zid,
            "zone_name": zname,
            "zone_type": ztype,
            "train_day_calls": day_c,
            "train_day_bands": exp_bands["day"],
            "day_rate_per_12h": round(r_day, 4),
            "train_night_calls": night_c,
            "train_night_bands": exp_bands["night"],
            "night_rate_per_12h": round(r_night, 4),
        })

    # 求解 MCLP（精確窮舉所有 C(6, K) 組合 vs 貪婪法 vs 現行靜態基準）
    def eval_combo(band, combo_set):
        cov_weight = 0.0
        tot_weight = 0.0
        covered_zones = []
        for zid in zones:
            w = lam_hat[(band, zid)]
            tot_weight += w
            best_t = min(t_mat[(band, sid, zid)] for sid in combo_set)
            if best_t <= tau_min:
                cov_weight += w
                covered_zones.append(zid)
        return cov_weight, cov_weight / tot_weight, covered_zones

    mclp_solutions = {}
    all_combos_rows = []
    for band in ("day", "night"):
        best_obj = -1.0
        best_combo = None
        for combo in itertools.combinations(stations, k_ambulances):
            cw, pct, cz = eval_combo(band, set(combo))
            all_combos_rows.append({
                "band": band,
                "stations": "+".join(combo),
                "expected_covered_per_12h": round(cw, 4),
                "expected_cov_pct": round(100 * pct, 2),
                "covered_zone_count": len(cz),
                "covered_zones": "|".join(cz),
            })
            if cw > best_obj + 1e-12:
                best_obj = cw
                best_combo = combo

        # 貪婪啟發式 (Greedy Adding)
        chosen = []
        for _ in range(k_ambulances):
            cand_best = max(
                (s for s in stations if s not in chosen),
                key=lambda s: eval_combo(band, set(chosen + [s]))[0],
            )
            chosen.append(cand_best)

        st_cw, st_pct, st_cz = eval_combo(band, static_set)
        op_cw, op_pct, op_cz = eval_combo(band, set(best_combo))
        gr_cw, gr_pct, _ = eval_combo(band, set(chosen))
        mclp_solutions[band] = {
            "static_stations": sorted(static_set),
            "static_expected_pct": round(100 * st_pct, 2),
            "optimal_stations": list(best_combo),
            "optimal_expected_pct": round(100 * op_pct, 2),
            "optimal_covered_zones": op_cz,
            "greedy_stations": sorted(chosen),
            "greedy_order": chosen,
            "greedy_expected_pct": round(100 * gr_pct, 2),
        }

    # W9–W16 獨立測試期回測（限 complete 班段，配對比較每一通真實報案）
    test_calls = [c for c in valid_calls if c["phase"] == "test" and c["sys_status"] == "complete"]
    weekly_rows = []
    week_blocks = []
    static_cov_all, dyn_cov_all = [], []
    static_t_all, dyn_t_all = [], []

    for wk in range(9, 17):
        wc = [c for c in test_calls if c["week"] == wk]
        s_cov, d_cov, diffs = [], [], []
        s_min, d_min = [], []
        for c in wc:
            b = c["band"]
            zid = c["zone_id"]
            t_s = min(t_mat[(b, sid, zid)] for sid in static_set)
            t_d = min(t_mat[(b, sid, zid)] for sid in mclp_solutions[b]["optimal_stations"])
            cs = int(t_s <= tau_min)
            cd = int(t_d <= tau_min)
            s_cov.append(cs)
            d_cov.append(cd)
            diffs.append(cd - cs)
            s_min.append(t_s)
            d_min.append(t_d)
            static_cov_all.append(cs)
            dyn_cov_all.append(cd)
            static_t_all.append(t_s)
            dyn_t_all.append(t_d)
        week_blocks.append(diffs)
        weekly_rows.append({
            "week": wk,
            "calls_n": len(wc),
            "static_cov_pct": round(100 * stats.mean(s_cov), 2),
            "dynamic_cov_pct": round(100 * stats.mean(d_cov), 2),
            "delta_pct": round(100 * (stats.mean(d_cov) - stats.mean(s_cov)), 2),
            "static_mean_min": round(stats.mean(s_min), 2),
            "dynamic_mean_min": round(stats.mean(d_min), 2),
        })

    # 週區塊配對拔靴法 4,000 次（估計 Δ 8分鐘涵蓋率百分點之 95% CI）
    rng = random.Random(3310)
    boot_deltas = []
    for _ in range(4000):
        sampled = rng.choices(week_blocks, k=len(week_blocks))
        tot_diff = sum(sum(blk) for blk in sampled)
        tot_n = sum(len(blk) for blk in sampled)
        boot_deltas.append(100.0 * tot_diff / tot_n)
    boot_deltas.sort()

    # 分班段（日間 vs 夜間）測試表現
    band_metrics = {}
    for b in ("day", "night"):
        bc = [c for c in test_calls if c["band"] == b]
        sc = [int(min(t_mat[(b, sid, c["zone_id"])] for sid in static_set) <= tau_min) for c in bc]
        dc = [int(min(t_mat[(b, sid, c["zone_id"])] for sid in mclp_solutions[b]["optimal_stations"]) <= tau_min) for c in bc]
        st_m = [min(t_mat[(b, sid, c["zone_id"])] for sid in static_set) for c in bc]
        dy_m = [min(t_mat[(b, sid, c["zone_id"])] for sid in mclp_solutions[b]["optimal_stations"]) for c in bc]
        band_metrics[b] = {
            "n": len(bc),
            "static_cov_pct": round(100 * stats.mean(sc), 2),
            "dynamic_cov_pct": round(100 * stats.mean(dc), 2),
            "delta_pct": round(100 * (stats.mean(dc) - stats.mean(sc)), 2),
            "static_mean_min": round(stats.mean(st_m), 2),
            "dynamic_mean_min": round(stats.mean(dy_m), 2),
        }

    test_summary = {
        "test_calls_n": len(test_calls),
        "static_cov_pct": round(100 * stats.mean(static_cov_all), 2),
        "dynamic_cov_pct": round(100 * stats.mean(dyn_cov_all), 2),
        "delta_cov_pct": round(100 * (stats.mean(dyn_cov_all) - stats.mean(static_cov_all)), 2),
        "delta_cov_ci95": [round(boot_deltas[99], 2), round(boot_deltas[3899], 2)],
        "static_mean_min": round(stats.mean(static_t_all), 2),
        "dynamic_mean_min": round(stats.mean(dyn_t_all), 2),
        "by_band": band_metrics,
    }
    return audit, zone_rates, all_combos_rows, mclp_solutions, weekly_rows, test_summary


def solve_mci_command(data_dir: Path):
    """Part B: 災時大量傷病患 (MCI) 前進指揮所 10 名醫護編組最佳化 + 多院容量約束後送最佳化"""
    hosps = read_csv(data_dir / "mci_hospitals.csv")
    patients = read_csv(data_dir / "mci_patients.csv")
    counts = Counter(p["triage_tag"] for p in patients)
    n_total = len(patients)       # 48 人
    n_red = counts["Red"]         # 14 人
    n_yellow = counts["Yellow"]   # 20 人
    n_green = counts["Green"]     # 14 人

    # ── 子模型 2A：前進指揮所 10 名急救人員三組配置（檢傷 Triage / 紅黃處置 Treatment / 後送協調 Transport）──
    # 參數（教學透明確定性瓶頸公式，可紙筆與 Excel 直接重算）：
    # • 檢傷組（n_tri >= 1）：每人每分鐘可完成 START 初檢 0.60 人 → 48 人檢傷完成時間 T_tri = 48 / (0.60 * n_tri) = 80 / n_tri
    # • 穩定處置組（n_trt >= 2）：紅牌每人需 15 人分、黃牌需 4.5 人分 → 總處置負荷 = 14*15 + 20*4.5 = 300 人分
    #   （首名傷患進場延遲 2.0 分鐘，處置完成時間 T_trt = 2.0 + 300 / n_trt）
    # • 後送裝載協調組（n_trp >= 1）：34 名紅黃傷患檢核上車與聯絡醫院，總負荷 88 人分 + 4.0 分鐘尾端交接 → T_trp = 4.0 + 88 / n_trp
    # 現場全部紅黃傷患完成穩定並發車之總清空時間 Makespan = max(T_tri + 4.0, T_trt + 2.0, T_trp)
    staff_rows = []
    best_staff = None
    for n_tri in range(1, 7):
        for n_trt in range(2, 9):
            n_trp = 10 - n_tri - n_trt
            if n_trp < 1:
                continue
            t_tri = 80.0 / n_tri + 4.0
            t_trt = 4.0 + 300.0 / n_trt
            t_trp = 4.0 + 88.0 / n_trp
            makespan = max(t_tri, t_trt, t_trp)
            bottleneck = (
                "檢傷入口瓶頸" if makespan == t_tri else
                ("紅黃處置瓶頸" if makespan == t_trt else "後送裝載瓶頸")
            )
            row = {
                "n_triage": n_tri,
                "n_treatment": n_trt,
                "n_transport": n_trp,
                "triage_stage_min": round(t_tri, 2),
                "treat_stage_min": round(t_trt, 2),
                "transport_stage_min": round(t_trp, 2),
                "clear_makespan_min": round(makespan, 2),
                "bottleneck": bottleneck,
            }
            staff_rows.append(row)
            if best_staff is None or makespan < best_staff["clear_makespan_min"]:
                best_staff = row

    # ── 子模型 2B：多院容量約束後送指派最佳化（Red=14, Yellow=20；Green=14 集中輕症巴士）──
    # 每超收 1 名紅牌產生 +22 分鐘走廊滯留等待懲罰；每超收 1 名黃牌產生 +12 分鐘等待懲罰；
    # 若誤將紅牌送往無重度開刀房之 H4，尚須二次轉院至 H1（額外 +35 分鐘轉院延遲！）
    h_info = []
    for h in hosps:
        h_info.append({
            "id": h["hospital_id"],
            "name": h["hospital_name"],
            "drive": float(h["drive_min_from_Z09"]),
            "rcap": int(h["red_capacity"]),
            "ycap": int(h["yellow_capacity"]),
            "surg": int(h["trauma_surgery"]),
        })

    def eval_dispatch(plan_name, red_alloc, yel_alloc):
        """計算特定指派方案之各項臨床指標（車程、超載等待、二次轉院、紅牌平均獲救時間與風險加權總人分）"""
        tot_weighted_min = 0.0
        red_total_min = 0.0
        yel_total_min = 0.0
        overload_patients = 0
        secondary_transfers = 0
        detail = []
        for idx, h in enumerate(h_info):
            ur = red_alloc[idx]
            uy = yel_alloc[idx]
            r_over = max(0, ur - h["rcap"])
            y_over = max(0, uy - h["ycap"])
            overload_patients += r_over + y_over
            # 若無外傷開刀房卻送紅牌，每名紅牌均需二次轉院 (+35 min)
            sec_tr = ur if h["surg"] == 0 else 0
            secondary_transfers += sec_tr
            # 超收排隊總延遲：第 1..r_over 名超收者平均等待 22 分鐘/人（或累積排隊）
            r_time = ur * h["drive"] + r_over * 22.0 + sec_tr * 13.0  # (r_over 已計 22，無開刀房共 +35)
            y_time = uy * h["drive"] + y_over * 12.0
            red_total_min += r_time
            yel_total_min += y_time
            tot_weighted_min += 3.0 * r_time + 1.0 * y_time
            detail.append({
                "plan": plan_name,
                "hospital_id": h["id"],
                "hospital_name": h["name"],
                "drive_min": h["drive"],
                "red_cap": h["rcap"],
                "red_assigned": ur,
                "yellow_cap": h["ycap"],
                "yellow_assigned": uy,
                "overload_n": r_over + y_over,
            })
        return {
            "plan": plan_name,
            "red_mean_min_to_care": round(red_total_min / n_red, 2),
            "yellow_mean_min_to_care": round(yel_total_min / n_yellow, 2),
            "overload_patients": overload_patients,
            "secondary_transfers": secondary_transfers,
            "risk_weighted_person_min": round(tot_weighted_min, 1),
            "detail": detail,
        }

    # 精確求解容量與專科約束下之全域最佳整數解：
    # H1(16m, R<=8, Y<=12), H2(12m, R<=5, Y<=10), H3(7m, R<=4, Y<=10), H4(9m, R<=0, Y<=12)
    best_opt = None
    for r1 in range(0, h_info[0]["rcap"] + 1):
        for r2 in range(0, h_info[1]["rcap"] + 1):
            for r3 in range(0, h_info[2]["rcap"] + 1):
                r4 = n_red - (r1 + r2 + r3)
                if r4 != 0:
                    continue
                for y1 in range(0, h_info[0]["ycap"] + 1):
                    for y2 in range(0, h_info[1]["ycap"] + 1):
                        for y3 in range(0, h_info[2]["ycap"] + 1):
                            y4 = n_yellow - (y1 + y2 + y3)
                            if 0 <= y4 <= h_info[3]["ycap"]:
                                cand = eval_dispatch("optimal_fcp", [r1, r2, r3, r4], [y1, y2, y3, y4])
                                if best_opt is None or cand["risk_weighted_person_min"] < best_opt["risk_weighted_person_min"]:
                                    best_opt = cand

    # 對照方案 1：無指揮所控管之「最近醫院直覺法（Nearest-Hospital Myopia）」
    # 80% 衝最近 H3(7m)，20% 衝次近 H4(9m，誤送無手術室地區醫院！)
    nearest_plan = eval_dispatch("nearest_myopia", [0, 0, 11, 3], [0, 2, 12, 6])

    # 對照方案 2：四院機械式平均分配法（Equal Split，未看專科與容量差異）
    equal_plan = eval_dispatch("equal_split", [4, 4, 3, 3], [5, 5, 5, 5])

    return {
        "patient_counts": {"total": n_total, "Red": n_red, "Yellow": n_yellow, "Green": n_green},
        "best_staffing": best_staff,
        "staffing_grid": staff_rows,
        "dispatch_comparison": [nearest_plan, equal_plan, best_opt],
    }


def run_all(data_dir: Path, out_dir: Path, k_ambulances: int = 4, tau_min: float = 8.0):
    out_dir.mkdir(parents=True, exist_ok=True)
    audit, zone_rates, combos, mclp, weekly, test_sum = audit_and_estimate_ems(data_dir, k_ambulances, tau_min)
    mci = solve_mci_command(data_dir)

    write_csv(out_dir / "zone_rates.csv", zone_rates)
    write_csv(out_dir / "mclp_combinations.csv", combos)
    write_csv(out_dir / "ems_weekly_backtest.csv", weekly)
    write_csv(out_dir / "fcp_staffing_grid.csv", mci["staffing_grid"])

    dispatch_rows = []
    for p in mci["dispatch_comparison"]:
        dispatch_rows.extend(p["detail"])
    write_csv(out_dir / "mci_dispatch_plans.csv", dispatch_rows)

    summary = {
        "params": {"k_ambulances": k_ambulances, "tau_min": tau_min},
        "ems_audit": audit,
        "mclp_solutions": mclp,
        "ems_test_summary": test_sum,
        "mci_summary": {
            "patient_counts": mci["patient_counts"],
            "best_staffing": mci["best_staffing"],
            "plans": [{k: v for k, v in p.items() if k != "detail"} for p in mci["dispatch_comparison"]],
        },
        "sources_sha256": {
            fn: hashlib.sha256((data_dir / fn).read_bytes()).hexdigest()
            for fn in ("travel_matrix.csv", "ems_calls.csv", "ems_shifts.csv", "mci_hospitals.csv", "mci_patients.csv")
        },
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, default=HERE / "data")
    ap.add_argument("--out", type=Path, default=HERE / "results")
    ap.add_argument("--ambulances", type=int, choices=(3, 4, 5), default=4)
    ap.add_argument("--threshold-min", type=float, default=8.0)
    args = ap.parse_args()
    res = run_all(args.data, args.out, args.ambulances, args.threshold_min)
    print(json.dumps({
        "ems_audit": res["ems_audit"],
        "mclp_solutions": res["mclp_solutions"],
        "ems_test_summary": res["ems_test_summary"],
        "mci_summary": res["mci_summary"],
    }, ensure_ascii=False, indent=2))
