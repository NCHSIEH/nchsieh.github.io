# -*- coding: utf-8 -*-
"""Automated reproducibility verification for S3 research kit."""
from pathlib import Path
import json
import tempfile
from generate import generate
from analyze import run_all

HERE = Path(__file__).resolve().parent


def main():
    with tempfile.TemporaryDirectory() as tmp:
        tmp_p = Path(tmp)
        regen_data = tmp_p / "data"
        generate(regen_data)
        for fn in ("travel_matrix.csv", "ems_calls.csv", "ems_shifts.csv", "mci_hospitals.csv", "mci_patients.csv"):
            assert (regen_data / fn).read_bytes() == (HERE / "data" / fn).read_bytes(), f"Data mismatch: {fn}"

        res_dir = tmp_p / "results"
        res = run_all(HERE / "data", res_dir, 4, 8.0)
        exp = json.loads((HERE / "expected/summary.json").read_text(encoding="utf-8"))
        assert res == exp, "Summary output mismatch against frozen expected/summary.json"

        for fn in ("zone_rates.csv", "mclp_combinations.csv", "ems_weekly_backtest.csv", "fcp_staffing_grid.csv", "mci_dispatch_plans.csv"):
            assert (res_dir / fn).read_text(encoding="utf-8-sig") == (HERE / "expected" / fn).read_text(encoding="utf-8-sig"), fn

        # Sensitivity check: K=3 ambulances (1 ambulance offline for maintenance)
        # Note: compare 3-ambulance dynamic staging against 3-ambulance static subset {S1,S2,S3}
        res_k3 = run_all(HERE / "data", tmp_p / "k3", 3, 8.0)
        assert res_k3["mclp_solutions"]["night"]["optimal_expected_pct"] > 50.0

    print("PASS: S3 deterministic data generation, MCLP & MCI optimal solutions, bootstrap CI, and K=3 sensitivity verified.")


if __name__ == "__main__":
    main()
