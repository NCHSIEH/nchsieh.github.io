# -*- coding: utf-8 -*-
"""S6 生成式 AI 衛教回答品質評估 — 分析程式（Python 3.8+，只用標準函式庫）

步驟：①合併盲化回答、評分與解盲鍵 ②評分者一致性（Cohen κ、二次加權 κ）
③共識分數（嚴重錯誤以裁決結果為準）④各來源嚴重錯誤率與 Wilson 95% CI
⑤配對比較：McNemar 精確檢定、要點涵蓋率配對差（以題目為單位拔靴）、Wilcoxon 符號等級
⑥風險分層、錯誤類型、長度與品質相關、正式研究樣本數
用法：python analyze.py [--out results]
"""
import argparse
import csv
import json
import math
import random
import statistics as st
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ARM_NAME = {"R": "護理師範本", "A": "LLM 基本提示", "B": "LLM 結構化提示"}


def read(name):
    with (HERE / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def cohen_kappa(a, b, cats):
    n = len(a)
    po = sum(1 for x, y in zip(a, b) if x == y) / n
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in cats)
    return po, pe, (po - pe) / (1 - pe)


def weighted_kappa(a, b, k=5):
    n = len(a)
    obs = [[0] * k for _ in range(k)]
    for x, y in zip(a, b):
        obs[x - 1][y - 1] += 1
    ra = [sum(obs[i]) for i in range(k)]
    cb = [sum(obs[i][j] for i in range(k)) for j in range(k)]
    num = den = 0.0
    for i in range(k):
        for j in range(k):
            w = (i - j) ** 2 / (k - 1) ** 2
            num += w * obs[i][j] / n
            den += w * ra[i] * cb[j] / n / n
    return 1 - num / den, obs


def wilson(x, n, z=1.959964):
    p = x / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return p, c - h, c + h


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def wilcoxon_signed_rank(diffs):
    d = [x for x in diffs if x != 0]
    n = len(d)
    absd = sorted((abs(x), i) for i, x in enumerate(d))
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and absd[j + 1][0] == absd[i][0]:
            j += 1
        r = (i + j) / 2 + 1
        for k in range(i, j + 1):
            ranks[absd[k][1]] = r
        i = j + 1
    wplus = sum(r for r, x in zip(ranks, d) if x > 0)
    mu = n * (n + 1) / 4
    ties = Counter(abs(x) for x in d)
    var = n * (n + 1) * (2 * n + 1) / 24 - sum(t ** 3 - t for t in ties.values()) / 48
    z = (wplus - mu) / math.sqrt(var)
    p = math.erfc(abs(z) / math.sqrt(2))
    return n, wplus, z, p


def spearman(x, y):
    def rank(v):
        s = sorted(range(len(v)), key=lambda i: v[i])
        r = [0.0] * len(v)
        i = 0
        while i < len(v):
            j = i
            while j + 1 < len(v) and v[s[j + 1]] == v[s[i]]:
                j += 1
            for k in range(i, j + 1):
                r[s[k]] = (i + j) / 2 + 1
            i = j + 1
        return r
    return st.correlation(rank(x), rank(y))


def mcnemar_n(p10, p01, alpha_z=1.959964, power_z=0.841621):
    pd = p10 + p01
    diff = p10 - p01
    return math.ceil((alpha_z * math.sqrt(pd) + power_z * math.sqrt(pd - diff ** 2)) ** 2 / diff ** 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    out = HERE / args.out
    out.mkdir(exist_ok=True)

    qs = {q["question_id"]: q for q in read("questions.csv")}
    ans = {a["answer_id"]: a for a in read("answers_blinded.csv")}
    key = {k["answer_id"]: k["arm"] for k in read("arm_key.csv")}
    r1 = {r["answer_id"]: r for r in read("ratings_r1.csv")}
    r2 = {r["answer_id"]: r for r in read("ratings_r2.csv")}
    adj = {r["answer_id"]: r for r in read("adjudication.csv")}
    ids = [a for a in sorted(ans, key=lambda k: int(ans[k]["present_order"]))]
    assert set(ids) == set(key) == set(r1) == set(r2), "檔案之間的 answer_id 不一致"

    # ② 評分者一致性（解盲前即可計算）
    h1 = [int(r1[i]["harm_severe"]) for i in ids]
    h2 = [int(r2[i]["harm_severe"]) for i in ids]
    po, pe, kap = cohen_kappa(h1, h2, [0, 1])
    tab = {"both1": sum(1 for a, b in zip(h1, h2) if a == b == 1), "r1only": sum(1 for a, b in zip(h1, h2) if a == 1 and b == 0),
           "r2only": sum(1 for a, b in zip(h1, h2) if a == 0 and b == 1), "both0": sum(1 for a, b in zip(h1, h2) if a == b == 0)}
    a1 = [int(r1[i]["accuracy_1to5"]) for i in ids]
    a2 = [int(r2[i]["accuracy_1to5"]) for i in ids]
    wk, mat = weighted_kappa(a1, a2)
    exact_acc = sum(1 for x, y in zip(a1, a2) if x == y) / len(ids)
    within1 = sum(1 for x, y in zip(a1, a2) if abs(x - y) <= 1) / len(ids)
    hl1 = [int(r1[i]["hallucination"]) for i in ids]
    hl2 = [int(r2[i]["hallucination"]) for i in ids]
    _, _, kap_h = cohen_kappa(hl1, hl2, [0, 1])

    # ③ 共識
    cons = []
    for i in ids:
        q = qs[ans[i]["question_id"]]
        nkp = int(q["n_keypoints"])
        if i in adj:
            harm = int(adj[i]["final_harm_severe"]); etype = adj[i]["final_error_type"]; src = "裁決"
        else:
            harm = h1[ids.index(i)]; etype = r1[i]["error_type"] if harm else "無"; src = "一致"
        cons.append({"answer_id": i, "question_id": q["question_id"], "topic": q["topic"], "risk": q["risk"], "arm": key[i],
                     "harm_severe": harm, "harm_source": src, "error_type": etype,
                     "hallucination": int(int(r1[i]["hallucination"]) + int(r2[i]["hallucination"]) >= 1),
                     "accuracy": (int(r1[i]["accuracy_1to5"]) + int(r2[i]["accuracy_1to5"])) / 2,
                     "coverage": (int(r1[i]["keypoints_covered"]) + int(r2[i]["keypoints_covered"])) / 2 / nkp,
                     "clarity": (int(r1[i]["clarity_1to5"]) + int(r2[i]["clarity_1to5"])) / 2,
                     "words": int(ans[i]["words"])})
    with (out / "consensus.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(cons[0]))
        w.writeheader(); w.writerows(cons)

    by = defaultdict(dict)
    for c in cons:
        by[c["arm"]][c["question_id"]] = c
    qids = sorted(qs)

    # ④ 各來源摘要
    arm_rows, arm_sum = [], {}
    for arm in ["R", "A", "B"]:
        rows = [by[arm][q] for q in qids]
        x = sum(r["harm_severe"] for r in rows)
        p, lo, hi = wilson(x, len(rows))
        hx = sum(r["hallucination"] for r in rows)
        hp, hlo, hhi = wilson(hx, len(rows))
        d = {"n": len(rows), "severe": x, "severe_pct": round(100 * p, 1), "severe_ci": [round(100 * lo, 1), round(100 * hi, 1)],
             "halluc": hx, "halluc_pct": round(100 * hp, 1), "halluc_ci": [round(100 * hlo, 1), round(100 * hhi, 1)],
             "accuracy_mean": round(st.mean(r["accuracy"] for r in rows), 2),
             "coverage_mean_pct": round(100 * st.mean(r["coverage"] for r in rows), 1),
             "clarity_mean": round(st.mean(r["clarity"] for r in rows), 2),
             "words_median": st.median(r["words"] for r in rows),
             "severe_high": sum(r["harm_severe"] for r in rows if r["risk"] == "high"),
             "severe_low": sum(r["harm_severe"] for r in rows if r["risk"] == "low")}
        arm_sum[arm] = d
        arm_rows.append({"arm": arm, "arm_name": ARM_NAME[arm], **{k: (v if not isinstance(v, list) else f"[{v[0]}, {v[1]}]") for k, v in d.items()}})
    with (out / "arm_summary.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(arm_rows[0]))
        w.writeheader(); w.writerows(arm_rows)
    n_high = sum(1 for q in qs.values() if q["risk"] == "high")

    # ⑤ 配對比較
    def pair(x_arm, y_arm):
        b = sum(1 for q in qids if by[x_arm][q]["harm_severe"] == 1 and by[y_arm][q]["harm_severe"] == 0)
        c = sum(1 for q in qids if by[x_arm][q]["harm_severe"] == 0 and by[y_arm][q]["harm_severe"] == 1)
        both = sum(1 for q in qids if by[x_arm][q]["harm_severe"] == 1 and by[y_arm][q]["harm_severe"] == 1)
        return {"x_only": b, "y_only": c, "both": both, "neither": len(qids) - b - c - both, "p_exact": round(mcnemar_exact(b, c), 4)}
    mc_ab = pair("A", "B")
    mc_ar = pair("A", "R")
    diffs = [by["B"][q]["coverage"] - by["A"][q]["coverage"] for q in qids]
    rng = random.Random(6602)
    boots = sorted(st.mean(rng.choices(diffs, k=len(diffs))) for _ in range(4000))
    cov = {"mean_diff_pct": round(100 * st.mean(diffs), 1), "boot95": [round(100 * boots[99], 1), round(100 * boots[3899], 1)],
           "n_better": sum(1 for d in diffs if d > 0), "n_worse": sum(1 for d in diffs if d < 0), "n_tie": sum(1 for d in diffs if d == 0)}
    acc_d = [by["B"][q]["accuracy"] - by["A"][q]["accuracy"] for q in qids]
    nw, wplus, z, pw = wilcoxon_signed_rank(acc_d)
    wil = {"n_nonzero": nw, "W_plus": wplus, "z": round(z, 2), "p": round(pw, 4), "mean_diff": round(st.mean(acc_d), 2)}

    # ⑥ 錯誤類型、長度與品質
    etypes = {arm: dict(Counter(by[arm][q]["error_type"] for q in qids if by[arm][q]["harm_severe"])) for arm in ["R", "A", "B"]}
    llm = [c for c in cons if c["arm"] in ("A", "B")]
    rho_len_acc = round(spearman([c["words"] for c in llm], [c["accuracy"] for c in llm]), 3)
    rho_len_cov = round(spearman([c["words"] for c in llm], [c["coverage"] for c in llm]), 3)
    # 敏感度：只用評分者 1
    sens_r1 = {arm: sum(int(r1[i]["harm_severe"]) for i in ids if key[i] == arm) for arm in ["R", "A", "B"]}
    p10 = mc_ab["x_only"] / len(qids); p01 = mc_ab["y_only"] / len(qids)

    summary = {
        "design": {"questions": len(qids), "high_risk": n_high, "low_risk": len(qids) - n_high, "arms": 3, "answers": len(ids),
                   "adjudicated": len(adj)},
        "agreement": {"harm_po": round(po, 4), "harm_pe": round(pe, 4), "harm_kappa": round(kap, 3), "harm_table": tab,
                      "accuracy_weighted_kappa": round(wk, 3), "accuracy_exact_pct": round(100 * exact_acc, 1),
                      "accuracy_within1_pct": round(100 * within1, 1), "halluc_kappa": round(kap_h, 3), "accuracy_matrix": mat},
        "arms": arm_sum,
        "mcnemar_A_vs_B": mc_ab, "mcnemar_A_vs_R": mc_ar,
        "coverage_B_minus_A": cov, "accuracy_B_vs_A_wilcoxon": wil,
        "error_types": etypes,
        "length_vs_quality_llm": {"spearman_words_accuracy": rho_len_acc, "spearman_words_coverage": rho_len_cov},
        "sensitivity_rater1_only_severe": sens_r1,
        "sample_size_mcnemar": {"p10": round(p10, 3), "p01": round(p01, 3), "n_questions_80pct_power": mcnemar_n(p10, p01)},
    }
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    a, b = arm_sum["A"], arm_sum["B"]
    print("S6 生成式 AI 衛教回答品質評估｜分析完成")
    print(f"  評分者一致性：嚴重錯誤 κ = {kap:.3f}（一致 {po:.1%}）；正確性二次加權 κ = {wk:.3f}")
    print(f"  嚴重錯誤率：R {arm_sum['R']['severe']}/40、A {a['severe']}/40（{a['severe_pct']}%）、B {b['severe']}/40（{b['severe_pct']}%）")
    print(f"  McNemar A vs B：只 A 錯 {mc_ab['x_only']}、只 B 錯 {mc_ab['y_only']}，精確 p = {mc_ab['p_exact']}")
    print(f"  要點涵蓋率 B − A：{cov['mean_diff_pct']} 個百分點（拔靴 95% CI {cov['boot95']}）")
    print(f"  正式研究建議題數（80% 檢定力）：{summary['sample_size_mcnemar']['n_questions_80pct_power']} 題")


if __name__ == "__main__":
    main()
