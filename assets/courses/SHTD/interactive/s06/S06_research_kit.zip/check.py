# -*- coding: utf-8 -*-
"""重跑 analyze.py 到暫存資料夾，逐項比對 expected/summary.json；相同即 PASS。"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(HERE / "analyze.py"), "--out", "_check_tmp"], check=True, stdout=subprocess.DEVNULL)
got = json.loads((HERE / "_check_tmp/summary.json").read_text(encoding="utf-8"))
exp = json.loads((HERE / "expected/summary.json").read_text(encoding="utf-8"))
bad = [k for k in exp if exp[k] != got.get(k)]
shutil.rmtree(HERE / "_check_tmp", ignore_errors=True)
if bad:
    print("FAIL：以下項目與 expected 不同 →", ", ".join(bad))
    sys.exit(1)
a = got["arms"]
print("=" * 60)
print("PASS！S06 生成式 AI 衛教回答品質評估工作包全數驗算相符")
print(f"  120 則盲化回答｜嚴重錯誤 κ = {got['agreement']['harm_kappa']}｜正確性加權 κ = {got['agreement']['accuracy_weighted_kappa']}")
print(f"  嚴重錯誤：R {a['R']['severe']}/40、A {a['A']['severe']}/40、B {a['B']['severe']}/40；McNemar A vs B p = {got['mcnemar_A_vs_B']['p_exact']}")
print("=" * 60)
