# -*- coding: utf-8 -*-
"""S4 Reproducible Evaluation Engine: Discrimination, Calibration, Temperature/Platt Scaling,
Shortcut Learning Edge-Mask Audit, and Decision Curve Analysis (DCA).
Python 3.9+, standard library only (zero pip dependencies).
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics as stats

HERE = Path(__file__).resolve().parent


def read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def sigmoid(z: float) -> float:
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    ez = math.exp(z)
    return ez / (1.0 + ez)


def auroc(y_true, y_score) -> float:
    """精確 Mann-Whitney U 秩和統計量計算 AUROC（支援平手分數平均秩）"""
    pairs = sorted(zip(y_score, y_true), key=lambda x: x[0])
    n = len(pairs)
    n_pos = sum(y_true)
    n_neg = n - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and pairs[j + 1][0] == pairs[i][0]:
            j += 1
        avg_r = (i + 1 + j + 1) / 2.0
        for k in range(i, j + 1):
            ranks[k] = avg_r
        i = j + 1
    sum_pos_ranks = sum(r for r, (_, y) in zip(ranks, pairs) if y == 1)
    return (sum_pos_ranks - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def auprc(y_true, y_score) -> float:
    """計算 Average Precision (AUPRC)"""
    pairs = sorted(zip(y_score, y_true), key=lambda x: -x[0])
    n_pos = sum(y_true)
    if n_pos == 0:
        return 0.0
    tp = 0
    fp = 0
    ap = 0.0
    for _, y in pairs:
        if y == 1:
            tp += 1
            ap += tp / (tp + fp)
        else:
            fp += 1
    return ap / n_pos


def brier_and_ece(y_true, y_prob, n_bins=5):
    """計算 Brier Score、平均預測機率與等寬 5 組預期校準誤差 (ECE)"""
    n = len(y_true)
    brier = sum((p - y) ** 2 for y, p in zip(y_true, y_prob)) / n
    bins = []
    ece = 0.0
    edges = [i / n_bins for i in range(n_bins + 1)]
    for b in range(n_bins):
        lo, hi = edges[b], edges[b + 1]
        idx = [i for i, p in enumerate(y_prob) if (lo <= p < hi if b < n_bins - 1 else lo <= p <= hi)]
        if idx:
            mp = stats.mean(y_prob[i] for i in idx)
            obs = stats.mean(y_true[i] for i in idx)
            ece += (len(idx) / n) * abs(mp - obs)
            bins.append({
                "bin": f"[{lo:.1f}, {hi:.1f}{']' if b==n_bins-1 else ')'}",
                "n": len(idx),
                "mean_pred": round(mp, 4),
                "observed_rate": round(obs, 4),
                "abs_gap": round(abs(mp - obs), 4),
            })
        else:
            bins.append({"bin": f"[{lo:.1f}, {hi:.1f})", "n": 0, "mean_pred": None, "observed_rate": None, "abs_gap": None})
    return round(brier, 4), round(ece, 4), round(stats.mean(y_prob), 4), bins


def fit_logistic_recalibration(logits, labels):
    """在獨立校正集 recal_dev (n=80) 上以最大概似法估計 p_cal = sigmoid(a + z / T)
    透過精細二維搜尋 + 局部牛頓微調最小化負對數概似 (NLL)，純標準庫零依賴。
    """
    def nll(a, inv_t):
        loss = 0.0
        for z, y in zip(logits, labels):
            eta = a + z * inv_t
            p = min(max(sigmoid(eta), 1e-12), 1.0 - 1e-12)
            loss -= y * math.log(p) + (1 - y) * math.log(1.0 - p)
        return loss

    best = (1e18, 0.0, 1.0)
    for ia in range(-300, 101, 5):
        a = ia / 100.0
        for it in range(20, 151, 2):
            inv_t = it / 100.0
            val = nll(a, inv_t)
            if val < best[0]:
                best = (val, a, inv_t)

    _, a0, b0 = best
    # Newton-Raphson 精化 15 步
    a, b = a0, b0
    for _ in range(15):
        g_a = g_b = h_aa = h_ab = h_bb = 0.0
        for z, y in zip(logits, labels):
            p = sigmoid(a + b * z)
            w = p * (1.0 - p)
            g_a += (p - y)
            g_b += (p - y) * z
            h_aa += w
            h_ab += w * z
            h_bb += w * z * z
        det = h_aa * h_bb - h_ab * h_ab
        if abs(det) < 1e-12:
            break
        a -= (h_bb * g_a - h_ab * g_b) / det
        b -= (-h_ab * g_a + h_aa * g_b) / det
    T = 1.0 / b
    return round(a, 4), round(T, 4), round(b, 4)


def confusion_and_dca(y_true, y_prob, pt: float):
    n = len(y_true)
    tp = sum(1 for y, p in zip(y_true, y_prob) if p >= pt and y == 1)
    fp = sum(1 for y, p in zip(y_true, y_prob) if p >= pt and y == 0)
    fn = sum(1 for y, p in zip(y_true, y_prob) if p < pt and y == 1)
    tn = sum(1 for y, p in zip(y_true, y_prob) if p < pt and y == 0)
    sens = tp / (tp + fn) if (tp + fn) else 0.0
    spec = tn / (tn + fp) if (tn + fp) else 0.0
    ppv = tp / (tp + fp) if (tp + fp) else 0.0
    npv = tn / (tn + fn) if (tn + fn) else 0.0
    nb_model = (tp / n) - (fp / n) * (pt / (1.0 - pt))
    prev = (tp + fn) / n
    nb_all = prev - (1.0 - prev) * (pt / (1.0 - pt))
    return {
        "threshold": pt,
        "flagged": tp + fp,
        "TP": tp, "FP": fp, "FN": fn, "TN": tn,
        "sens_pct": round(100 * sens, 2),
        "spec_pct": round(100 * spec, 2),
        "ppv_pct": round(100 * ppv, 2),
        "npv_pct": round(100 * npv, 2),
        "net_benefit": round(nb_model, 4),
        "nb_treat_all": round(nb_all, 4),
    }


def run_all(data_dir: Path, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Site A 病人級 vs 影像級切分洩漏比較
    sa = read_csv(data_dir / "site_a_splits.csv")
    img_test = [r for r in sa if r["image_split"] == "test"]
    pat_test = [r for r in sa if r["patient_split"] == "test"]
    train_pids_img = {r["patient_id"] for r in sa if r["image_split"] == "train"}
    leaked_films = sum(1 for r in img_test if r["patient_id"] in train_pids_img)

    auc_leaked = auroc([int(r["pneumonia_label"]) for r in img_test], [float(r["prob_image_leaked"]) for r in img_test])
    auc_clean = auroc([int(r["pneumonia_label"]) for r in pat_test], [float(r["prob_patient_split"]) for r in pat_test])
    leakage_audit = {
        "site_a_total_films": len(sa),
        "site_a_unique_patients": len({r["patient_id"] for r in sa}),
        "image_split_test_films": len(img_test),
        "leaked_overlap_films_in_test": leaked_films,
        "auroc_image_split_leaked": round(auc_leaked, 4),
        "auroc_patient_split_clean": round(auc_clean, 4),
        "inflation_delta": round(auc_leaked - auc_clean, 4),
    }

    # 2. Site B 外部資料清理與雙子集分離
    sb_raw = read_csv(data_dir / "site_b_external.csv")
    seen = set()
    dups = 0
    corrupt = 0
    dev_rows, test_rows = [], []
    for r in sb_raw:
        key = (r["image_id"], r["patient_id"], r["cohort"], r["image_quality"])
        if r["image_id"] in seen and r["image_quality"] == "ok":
            dups += 1
            continue
        seen.add(r["image_id"])
        if r["image_quality"] != "ok":
            corrupt += 1
            continue
        if r["cohort"] == "recal_dev":
            dev_rows.append(r)
        elif r["cohort"] == "ext_test":
            test_rows.append(r)

    test_rows.sort(key=lambda x: x["patient_id"])
    audit = {
        "site_b_raw_rows": len(sb_raw),
        "duplicates_removed": dups,
        "corrupt_excluded": corrupt,
        "recal_dev_n": len(dev_rows),
        "ext_test_n": len(test_rows),
        "ext_test_pos": sum(int(r["pneumonia_label"]) for r in test_rows),
        "ext_test_prevalence_pct": round(100 * stats.mean(int(r["pneumonia_label"]) for r in test_rows), 2),
    }

    # 3. 在 recal_dev (n=80) 估計溫度縮放與截距重校準參數，鎖定套用至 ext_test (N=240)
    a_hat, T_hat, slope_hat = fit_logistic_recalibration(
        [float(r["cnn_logit_raw"]) for r in dev_rows],
        [int(r["pneumonia_label"]) for r in dev_rows],
    )

    y_test = [int(r["pneumonia_label"]) for r in test_rows]
    p_base = [float(r["baseline_prob"]) for r in test_rows]
    p_raw = [sigmoid(float(r["cnn_logit_raw"])) for r in test_rows]
    p_cal = [sigmoid(a_hat + float(r["cnn_logit_raw"]) / T_hat) for r in test_rows]
    p_mask = [sigmoid(float(r["cnn_logit_masked"])) for r in test_rows]

    # 4. 鑑別力與病人級配對拔靴 95% CI (4,000 次)
    auc_base = auroc(y_test, p_base)
    auc_raw = auroc(y_test, p_raw)
    auc_cal = auroc(y_test, p_cal)
    auc_mask = auroc(y_test, p_mask)

    rng = random.Random(4402)
    n_t = len(y_test)
    boot_diffs = []
    for _ in range(4000):
        idxs = [rng.randrange(n_t) for _ in range(n_t)]
        yb = [y_test[i] for i in idxs]
        if 0 < sum(yb) < n_t:
            boot_diffs.append(auroc(yb, [p_raw[i] for i in idxs]) - auroc(yb, [p_base[i] for i in idxs]))
    boot_diffs.sort()

    # 5. 校準指標與分組校準表
    brier_base, ece_base, mp_base, _ = brier_and_ece(y_test, p_base)
    brier_raw, ece_raw, mp_raw, bins_raw = brier_and_ece(y_test, p_raw)
    brier_cal, ece_cal, mp_cal, bins_cal = brier_and_ece(y_test, p_cal)

    cal_table = []
    for br, bc in zip(bins_raw, bins_cal):
        cal_table.append({
            "prob_bin": br["bin"],
            "raw_n": br["n"],
            "raw_mean_pred": br["mean_pred"],
            "raw_observed": br["observed_rate"],
            "cal_n": bc["n"],
            "cal_mean_pred": bc["mean_pred"],
            "cal_observed": bc["observed_rate"],
        })
    write_csv(out_dir / "calibration_bins.csv", cal_table)

    # 6. 捷徑學習 (Shortcut Learning: AP_portable vs PA_upright) 與邊框遮罩稽核
    shortcut_rows = []
    for v_tag in ("AP_portable", "PA_upright"):
        sub_idx = [i for i, r in enumerate(test_rows) if r["view_position"] == v_tag]
        ys = [y_test[i] for i in sub_idx]
        pr = [p_raw[i] for i in sub_idx]
        pm = [p_mask[i] for i in sub_idx]
        pc = [p_cal[i] for i in sub_idx]
        neg_idx = [i for i in sub_idx if y_test[i] == 0]
        fpr_raw20 = 100 * stats.mean(p_raw[i] >= 0.20 for i in neg_idx)
        fpr_mask20 = 100 * stats.mean(p_mask[i] >= 0.20 for i in neg_idx)
        shortcut_rows.append({
            "view_position": v_tag,
            "n": len(sub_idx),
            "prevalence_pct": round(100 * stats.mean(ys), 2),
            "auroc_raw": round(auroc(ys, pr), 4),
            "auroc_edge_masked": round(auroc(ys, pm), 4),
            "mean_prob_raw": round(stats.mean(pr), 4),
            "mean_prob_edge_masked": round(stats.mean(pm), 4),
            "neg_fpr_at_020_raw_pct": round(fpr_raw20, 2),
            "neg_fpr_at_020_masked_pct": round(fpr_mask20, 2),
        })
    write_csv(out_dir / "shortcut_audit.csv", shortcut_rows)

    # 7. 閾值與決策曲線分析 (DCA at thresholds 0.10, 0.15, 0.20, 0.25, 0.30)
    dca_rows = []
    for pt in (0.10, 0.15, 0.20, 0.25, 0.30):
        m_raw = confusion_and_dca(y_test, p_raw, pt)
        m_cal = confusion_and_dca(y_test, p_cal, pt)
        m_bas = confusion_and_dca(y_test, p_base, pt)
        dca_rows.append({
            "threshold_pt": pt,
            "nb_treat_all": m_cal["nb_treat_all"],
            "nb_baseline": m_bas["net_benefit"],
            "nb_cnn_raw": m_raw["net_benefit"],
            "nb_cnn_calibrated": m_cal["net_benefit"],
            "cal_flagged": m_cal["flagged"],
            "cal_TP": m_cal["TP"],
            "cal_FP": m_cal["FP"],
            "cal_sens_pct": m_cal["sens_pct"],
            "cal_ppv_pct": m_cal["ppv_pct"],
            "raw_flagged": m_raw["flagged"],
            "raw_FP": m_raw["FP"],
        })
    write_csv(out_dir / "threshold_dca.csv", dca_rows)

    # 逐病人測試預測輸出表
    pred_rows = []
    for i, r in enumerate(test_rows):
        pred_rows.append({
            "patient_id": r["patient_id"],
            "age_group": r["age_group"],
            "view_position": r["view_position"],
            "y": y_test[i],
            "baseline_prob": round(p_base[i], 4),
            "cnn_logit_raw": r["cnn_logit_raw"],
            "cnn_prob_raw": round(p_raw[i], 4),
            "cnn_prob_calibrated": round(p_cal[i], 4),
            "cnn_prob_edge_masked": round(p_mask[i], 4),
        })
    write_csv(out_dir / "test_predictions.csv", pred_rows)

    summary = {
        "leakage_experiment": leakage_audit,
        "external_audit": audit,
        "recalibration_fit": {"intercept_a": a_hat, "temperature_T": T_hat, "inv_T_slope": slope_hat},
        "models_ext_test": {
            "baseline": {"auroc": round(auc_base, 4), "auprc": round(auprc(y_test, p_base), 4),
                         "brier": brier_base, "ece": ece_base, "mean_pred": mp_base},
            "cnn_raw": {"auroc": round(auc_raw, 4), "auprc": round(auprc(y_test, p_raw), 4),
                        "brier": brier_raw, "ece": ece_raw, "mean_pred": mp_raw},
            "cnn_calibrated": {"auroc": round(auc_cal, 4), "auprc": round(auprc(y_test, p_cal), 4),
                               "brier": brier_cal, "ece": ece_cal, "mean_pred": mp_cal},
            "cnn_edge_masked": {"auroc": round(auc_mask, 4), "auprc": round(auprc(y_test, p_mask), 4)},
        },
        "delta_auroc_cnn_vs_base": {
            "est": round(auc_raw - auc_base, 4),
            "ci95": [round(boot_diffs[99], 4), round(boot_diffs[3899], 4)],
        },
        "shortcut_summary": shortcut_rows,
        "sources_sha256": {
            fn: hashlib.sha256((data_dir / fn).read_bytes()).hexdigest()
            for fn in ("site_a_splits.csv", "site_b_external.csv")
        },
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, default=HERE / "data")
    ap.add_argument("--out", type=Path, default=HERE / "results")
    res = run_all(ap.parse_args().data, ap.parse_args().out)
    print(json.dumps(res, ensure_ascii=False, indent=2))
