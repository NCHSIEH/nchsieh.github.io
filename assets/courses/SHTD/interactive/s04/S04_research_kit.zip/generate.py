# -*- coding: utf-8 -*-
"""Generate deterministic synthetic datasets for S4 (CNN Medical Image Validation, Calibration & Shortcut Audit).
Python 3.9+, standard library only. Fixed seed = 4401.
"""
import argparse
import csv
import math
from pathlib import Path
import random


def sigmoid(z):
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    ez = math.exp(z)
    return ez / (1.0 + ez)


def write_csv(path: Path, header, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def generate(folder: Path):
    folder.mkdir(parents=True, exist_ok=True)
    rng = random.Random(4401)

    # 1. Site A 同院重複拍片切分洩漏示範檔 (site_a_splits.csv)
    # 160 位住院病人（25% 陽性平均分布於 train 與 test），每人拍 1~3 張連續追蹤 X 光（共 320 張）
    site_a_rows = []
    img_seq = 1
    for p_idx in range(1, 161):
        pid = f"PA-{p_idx:03d}"
        y = 1 if (p_idx % 4 == 1) else 0  # train(1..80) 與 test(81..160) 各精確 25.0% 陽性 (20/80)
        n_imgs = 3 if p_idx % 3 == 0 else (2 if p_idx % 2 == 0 else 1)
        pat_split = "train" if p_idx <= 80 else "test"
        pat_noise = rng.gauss(0.0, 0.70)
        for k in range(n_imgs):
            img_split = "train" if (k == 0 or (n_imgs == 1 and p_idx % 2 == 1)) else "test"
            true_sig = (1.15 if y == 1 else -0.95) + pat_noise + rng.gauss(0.0, 0.85)
            pat_eval_prob = round(sigmoid(true_sig), 4)
            # 若採錯誤影像級切分，有重疊片之病人因記憶骨架/管路特徵被虛假推高
            leak_shift = (1.35 if y == 1 else -1.35) if n_imgs >= 2 else 0.0
            img_leaked_prob = round(sigmoid(true_sig + leak_shift), 4)
            site_a_rows.append([
                f"CXR-A{img_seq:04d}", pid, k + 1, y, pat_split, img_split,
                pat_eval_prob, img_leaked_prob
            ])
            img_seq += 1

    write_csv(
        folder / "site_a_splits.csv",
        ["image_id", "patient_id", "film_order", "pneumonia_label", "patient_split", "image_split",
         "prob_patient_split", "prob_image_leaked"],
        site_a_rows,
    )

    # 2. Site B 東城社區醫院外部資料集 (site_b_external.csv)
    # recal_dev: 80 人 (12 陽性 = 15.0%)；ext_test: 240 人 (36 陽性 = 15.0%)
    def make_site_b_cohort(prefix, n_pos, n_neg, cohort_tag):
        items = ([1] * n_pos) + ([0] * n_neg)
        rng.shuffle(items)
        out = []
        for i, y in enumerate(items, 1):
            pid = f"{prefix}-{i:03d}"
            age = rng.randint(58, 86) if y == 1 else rng.randint(28, 82)
            age_grp = "65plus" if age >= 65 else "under65"
            p_port = 0.56 if y == 1 else (0.20 if age >= 65 else 0.12)
            is_port = 1 if rng.random() < p_port else 0
            view = "AP_portable" if is_port else "PA_upright"

            # 傳統臨床基準分數（AUROC ~ 0.74）
            z_base = -1.72 + (0.92 if y == 1 else -0.18) + rng.gauss(0.0, 1.08)
            p_base = round(sigmoid(z_base), 4)

            # CNN 真實肺實變病灶訊號 + 深度網路過度自信放大 (×2.15 → T > 1 需降溫!) + 開發院區偏移 (+1.10) + PORTABLE 捷徑 (+1.65)
            lesion_sig = (0.98 if y == 1 else -0.62) + rng.gauss(0.0, 0.92)
            shortcut_bias = 1.65 if is_port else -0.20
            logit_raw = round(1.05 + 2.15 * lesion_sig + shortcut_bias, 4)
            logit_masked = round(1.05 + 2.15 * lesion_sig - 0.10, 4)

            out.append([
                f"CXR-{pid}", pid, cohort_tag, age, age_grp, view, "ok", y,
                p_base, logit_raw, round(sigmoid(logit_raw), 4),
                logit_masked, round(sigmoid(logit_masked), 4)
            ])
        return out

    site_b_rows = []
    site_b_rows.extend(make_site_b_cohort("BDEV", 12, 68, "recal_dev"))
    site_b_rows.extend(make_site_b_cohort("BTST", 36, 204, "ext_test"))

    # 加入 3 張獨立曝光失敗/DICOM 破損紀錄 (corrupt_exposure) 與 2 列完全重複匯出
    for c_i in range(1, 4):
        site_b_rows.append([
            f"CXR-BCOR-{c_i:02d}", f"BCOR-{c_i:02d}", "ext_test", 66, "65plus",
            "AP_portable", "corrupt_exposure", "", "", "", "", "", ""
        ])
    site_b_rows.append(site_b_rows[8][:])
    site_b_rows.append(site_b_rows[115][:])

    rng.shuffle(site_b_rows)
    write_csv(
        folder / "site_b_external.csv",
        ["image_id", "patient_id", "cohort", "age", "age_group", "view_position", "image_quality",
         "pneumonia_label", "baseline_prob", "cnn_logit_raw", "cnn_prob_raw", "cnn_logit_masked", "cnn_prob_masked"],
        site_b_rows,
    )


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "data")
    generate(ap.parse_args().out)
    print("Generated S4 synthetic CNN audit datasets successfully.")
