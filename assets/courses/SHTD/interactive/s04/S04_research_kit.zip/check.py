# -*- coding: utf-8 -*-
"""Automated reproducibility verification for S4 CNN Validation & Shortcut Audit kit."""
from pathlib import Path
import json
import tempfile
from generate import generate
from analyze import run_all

HERE = Path(__file__).resolve().parent


def main():
    with tempfile.TemporaryDirectory() as tmp:
        tp = Path(tmp)
        regen = tp / "data"
        generate(regen)
        for fn in ("site_a_splits.csv", "site_b_external.csv"):
            assert (regen / fn).read_bytes() == (HERE / "data" / fn).read_bytes(), fn

        res = run_all(HERE / "data", tp / "results")
        exp = json.loads((HERE / "expected/summary.json").read_text(encoding="utf-8"))
        assert res == exp, "Summary mismatch against frozen expected/summary.json"
        # Verify monotonic invariance: calibration preserves AUROC identically
        assert res["models_ext_test"]["cnn_raw"]["auroc"] == res["models_ext_test"]["cnn_calibrated"]["auroc"]
        assert res["models_ext_test"]["cnn_calibrated"]["ece"] < res["models_ext_test"]["cnn_raw"]["ece"]

    print("PASS: S4 CNN leakage audit, external AUROC/AUPRC, Platt/Temperature recalibration, shortcut audit, and DCA verified.")


if __name__ == "__main__":
    main()
