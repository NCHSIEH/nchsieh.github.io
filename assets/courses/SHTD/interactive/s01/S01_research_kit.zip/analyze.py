"""S1 paired heart-rate pilot. Run with Python 3.8+ using only its standard library."""
import argparse
import csv
import html
import math
import random
import statistics as st
from collections import Counter
from pathlib import Path


def csv_out(path, fields, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def value(row, key):
    raw = row[key].strip()
    if not raw:
        return None
    number = float(raw)
    if not math.isfinite(number):
        raise ValueError(f"{row['id']}: invalid {key}")
    return number


def limits(differences):
    avg = st.mean(differences)
    span = 1.96 * st.stdev(differences)
    return avg, avg - span, avg + span


def quantile(sorted_values, fraction):
    index = (len(sorted_values) - 1) * fraction
    weight = index % 1
    return sorted_values[int(index)] * (1 - weight) + sorted_values[math.ceil(index)] * weight


def draw(pairs, estimates, destination):
    width, height = 700, 360
    xs = [x for x, _ in pairs]
    ys = [y for _, y in pairs] + list(estimates) + [-5, 5]
    lo, hi = math.floor(min(xs)) - 1, math.ceil(max(xs)) + 1
    bottom, top = math.floor(min(ys)) - 1, math.ceil(max(ys)) + 1
    x_at = lambda v: 65 + 475 * (v - lo) / (hi - lo)
    y_at = lambda v: 290 - 240 * (v - bottom) / (top - bottom)
    svg = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 360" role="img"><title>合成心率配對一致性圖</title><rect width="700" height="360" fill="white"/>',
           '<g font-family="sans-serif" font-size="14"><text x="15" y="24">腕式 − 參考（bpm）</text>']
    for y in range(bottom, top + 1, max(1, math.ceil((top-bottom)/7))):
        svg.append(f'<path d="M65 {y_at(y)}h475" stroke="#dce1e5"/><text x="50" y="{y_at(y)+5}" text-anchor="end">{y}</text>')
    for x in range(lo, hi+1, max(1, math.ceil((hi-lo)/6))):
        svg.append(f'<text x="{x_at(x)}" y="315" text-anchor="middle">{x}</text>')
    for v, name in zip(estimates, ["平均差", "下界", "上界"]):
        svg.append(f'<path d="M65 {y_at(v)}h475" stroke="#9b491c" stroke-dasharray="6 3"/><text x="548" y="{y_at(v)+4}">{html.escape(name)} {v:+.2f}</text>')
    for x, y in pairs:
        svg.append(f'<circle cx="{x_at(x)}" cy="{y_at(y)}" r="4.8" fill="#174b68" opacity=".76"/>')
    svg.append('<text x="300" y="348" text-anchor="middle">兩法平均（bpm）</text></g></svg>')
    destination.write_text("".join(svg), encoding="utf-8")


def analyze(source, output, tolerance):
    with source.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    ids = [r["id"].strip() for r in rows]
    if not all(ids) or len(set(ids)) != len(ids):
        raise ValueError("每位參與者應有一筆排程。請回查空白或重複的 id。")
    audit, pairs, reasons = [], [], Counter()
    fidelity = 0
    for row in rows:
        watch, ref, offset = [value(row, k) for k in ("wrist_bpm", "ref_bpm", "start_gap_s")]
        if row["signal_ok"] not in {"0","1"} or row["checklist_done"] not in {"0","1"}:
            raise ValueError("signal_ok and checklist_done require 0 or 1")
        fidelity += int(row["checklist_done"])
        if watch is None:
            reason = "missing_wrist"
        elif ref is None:
            reason = "missing_reference"
        elif row["signal_ok"] == "0":
            reason = "poor_signal"
        elif offset is None or abs(offset) > tolerance:
            reason = "unpaired_time"
        else:
            reason = "include"
            pairs.append(((watch + ref) / 2, watch - ref))
        reasons[reason] += 1
        audit.append(dict(id=row["id"], reason=reason,
                          mean_bpm=pairs[-1][0] if reason == "include" else "",
                          diff_bpm=pairs[-1][1] if reason == "include" else ""))
    if len(pairs) < 3:
        raise ValueError("有效配對不足三筆，回查原始檔及配對容許秒數。")
    diffs = [y for _, y in pairs]
    estimates = limits(diffs)
    rng = random.Random(410)
    bootstrap = [limits(rng.choices(diffs, k=len(diffs))) for _ in range(5000)]
    output.mkdir(exist_ok=True, parents=True)
    csv_out(output / "audit.csv", ["id","reason","mean_bpm","diff_bpm"], audit)
    report = [f"planned={len(rows)}", f"included={len(pairs)}", f"coverage={len(pairs)/len(rows):.1%}",
              f"checklist={fidelity}/{len(rows)}", f"max_start_gap_s={tolerance:g}",
              f"exclusions={dict(sorted((k,v) for k,v in reasons.items() if k != 'include'))}",
              f"mae_bpm={st.mean(map(abs,diffs)):.2f}"]
    for index, name in enumerate(["bias", "lower_loa", "upper_loa"]):
        sample = sorted(r[index] for r in bootstrap)
        report.append(f"{name}={estimates[index]:+.2f}  bootstrap95=[{quantile(sample,.025):+.2f}, {quantile(sample,.975):+.2f}]")
    draw(pairs, estimates, output / "agreement.svg")
    txt = "\n".join(report) + "\n"
    (output / "results.txt").write_text(txt, encoding="utf-8")
    print(txt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    folder = Path(__file__).resolve().parent
    parser.add_argument("--input", type=Path, default=folder/"pairs.csv")
    parser.add_argument("--out", type=Path, default=folder/"results")
    parser.add_argument("--gap", type=float, default=5)
    args = parser.parse_args()
    if not math.isfinite(args.gap) or args.gap < 0:
        parser.error("--gap must be finite and nonnegative")
    analyze(args.input, args.out, args.gap)

