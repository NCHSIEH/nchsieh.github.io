# -*- coding: utf-8 -*-
"""S5 正念冥想減壓等候名單對照試驗與 ANCOVA 分析 — 純標準庫可重現統計驗證程式"""
from pathlib import Path
import csv
import json
import math
import random

HERE = Path(__file__).resolve().parent


def mean(xs):
    return sum(xs) / len(xs)


def var_sample(xs):
    m = mean(xs)
    return sum((x - m) ** 2 for x in xs) / (len(xs) - 1)


def sd_sample(xs):
    return math.sqrt(var_sample(xs))


def normal_cdf(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def t_two_sided_pvalue(t_val, df):
    """Accurate two-sided p-value for Student's t using Cornish-Fisher / normal-t series."""
    x = abs(t_val)
    if x == 0:
        return 1.0
    # Wallace / Peizer-Pratt accurate normal approximation to t-distribution for df >= 5
    z = math.sqrt(df * math.log(1.0 + (x * x) / df)) * (1.0 - 1.0 / (4.0 * df) + 1.0 / (32.0 * df * df))
    return 2.0 * (1.0 - normal_cdf(z))


def t_crit_95(df):
    """97.5% quantile of Student's t via Peizer-Pratt inverse expansion."""
    z = 1.959963984540054
    z3 = z ** 3
    z5 = z ** 5
    return z + (z3 + z) / (4.0 * df) + (5.0 * z5 + 16.0 * z3 + 3.0 * z) / (96.0 * df * df)


def paired_t(pre, post):
    diffs = [b - a for a, b in zip(pre, post)]
    n = len(diffs)
    m = mean(diffs)
    sd = sd_sample(diffs)
    se = sd / math.sqrt(n)
    t_val = m / se
    tc = t_crit_95(n - 1)
    return {
        "n": n,
        "mean_pre": round(mean(pre), 4),
        "mean_post": round(mean(post), 4),
        "mean_change": round(m, 4),
        "sd_change": round(sd, 4),
        "se_change": round(se, 4),
        "t_stat": round(t_val, 4),
        "df": n - 1,
        "p_two_sided": round(t_two_sided_pvalue(t_val, n - 1), 6),
        "ci95_low": round(m - tc * se, 4),
        "ci95_high": round(m + tc * se, 4),
    }


def two_sample_t(y1, y0):
    """Pooled-variance two-sample t-test: y1 (Mindful) - y0 (Waitlist)."""
    n1, n0 = len(y1), len(y0)
    m1, m0 = mean(y1), mean(y0)
    v1, v0 = var_sample(y1), var_sample(y0)
    df = n1 + n0 - 2
    sp2 = ((n1 - 1) * v1 + (n0 - 1) * v0) / df
    se = math.sqrt(sp2 * (1.0 / n1 + 1.0 / n0))
    diff = m1 - m0
    t_val = diff / se
    tc = t_crit_95(df)
    # Hedges' g small-sample correction
    j_corr = 1.0 - 3.0 / (4.0 * df - 1.0)
    hedges_g = (diff / math.sqrt(sp2)) * j_corr
    return {
        "n_mindful": n1,
        "n_waitlist": n0,
        "mean_mindful": round(m1, 4),
        "mean_waitlist": round(m0, 4),
        "diff": round(diff, 4),
        "se": round(se, 4),
        "t_stat": round(t_val, 4),
        "df": df,
        "p_two_sided": round(t_two_sided_pvalue(t_val, df), 6),
        "ci95_low": round(diff - tc * se, 4),
        "ci95_high": round(diff + tc * se, 4),
        "hedges_g": round(hedges_g, 4),
    }


def ols_ancova(g_list, x_pre_list, y_post_list):
    """
    Exact closed-form OLS ANCOVA:
      Y_post = beta_0 + beta_1 * G + beta_2 * (X_pre - X_bar_all) + eps
    Using within-group centering identity:
      beta_2_hat = S_xy_within / S_xx_within
      beta_1_hat = (Y_bar_1 - Y_bar_0) - beta_2_hat * (X_bar_1 - X_bar_0)
    """
    n = len(y_post_list)
    x_bar_all = mean(x_pre_list)

    idx1 = [i for i, g in enumerate(g_list) if g == 1]
    idx0 = [i for i, g in enumerate(g_list) if g == 0]
    n1, n0 = len(idx1), len(idx0)

    x1 = [x_pre_list[i] for i in idx1]
    y1 = [y_post_list[i] for i in idx1]
    x0 = [x_pre_list[i] for i in idx0]
    y0 = [y_post_list[i] for i in idx0]

    xb1, yb1 = mean(x1), mean(y1)
    xb0, yb0 = mean(x0), mean(y0)

    sxx_1 = sum((v - xb1) ** 2 for v in x1)
    sxy_1 = sum((x1[k] - xb1) * (y1[k] - yb1) for k in range(n1))
    sxx_0 = sum((v - xb0) ** 2 for v in x0)
    sxy_0 = sum((x0[k] - xb0) * (y0[k] - yb0) for k in range(n0))

    sxx_w = sxx_1 + sxx_0
    sxy_w = sxy_1 + sxy_0

    beta2 = sxy_w / sxx_w
    adj_mean_1 = yb1 - beta2 * (xb1 - x_bar_all)
    adj_mean_0 = yb0 - beta2 * (xb0 - x_bar_all)
    beta1 = adj_mean_1 - adj_mean_0  # = (yb1 - yb0) - beta2 * (xb1 - xb0)
    beta0 = adj_mean_0

    # Residuals and MSE (df = n - 3)
    df = n - 3
    sse = 0.0
    y_bar_all = mean(y_post_list)
    sst = sum((v - y_bar_all) ** 2 for v in y_post_list)
    for g, x, y in zip(g_list, x_pre_list, y_post_list):
        y_hat = beta0 + beta1 * g + beta2 * (x - x_bar_all)
        sse += (y - y_hat) ** 2
    mse = sse / df
    rmse = math.sqrt(mse)
    r2 = 1.0 - sse / sst

    # Exact SE of beta_1 in ANCOVA:
    # Var(beta1_hat) = MSE * [ 1/n1 + 1/n0 + (xb1 - xb0)^2 / S_xx_within ]
    se_beta1 = math.sqrt(mse * (1.0 / n1 + 1.0 / n0 + ((xb1 - xb0) ** 2) / sxx_w))
    se_beta2 = math.sqrt(mse / sxx_w)
    t_beta1 = beta1 / se_beta1
    tc = t_crit_95(df)

    # Partial eta-squared for Group: t^2 / (t^2 + df)
    partial_eta2 = (t_beta1 ** 2) / (t_beta1 ** 2 + df)

    # Check homogeneity of regression slopes interaction term (G * X_pre)
    slope1 = sxy_1 / sxx_1
    slope0 = sxy_0 / sxx_0
    sse_sep = sum((y1[k] - (yb1 + slope1 * (x1[k] - xb1))) ** 2 for k in range(n1)) + \
              sum((y0[k] - (yb0 + slope0 * (x0[k] - xb0))) ** 2 for k in range(n0))
    df_int = n - 4
    f_int = ((sse - sse_sep) / 1.0) / (sse_sep / df_int)
    p_int = t_two_sided_pvalue(math.sqrt(max(0.0, f_int)), df_int)

    return {
        "n_total": n,
        "n_mindful": n1,
        "n_waitlist": n0,
        "x_bar_all": round(x_bar_all, 4),
        "x_bar_mindful": round(xb1, 4),
        "x_bar_waitlist": round(xb0, 4),
        "raw_post_mindful": round(yb1, 4),
        "raw_post_waitlist": round(yb0, 4),
        "sxx_within": round(sxx_w, 4),
        "sxy_within": round(sxy_w, 4),
        "beta0_adj_waitlist": round(beta0, 4),
        "adj_mean_mindful": round(adj_mean_1, 4),
        "adj_mean_waitlist": round(adj_mean_0, 4),
        "beta1_group_effect": round(beta1, 4),
        "beta2_baseline_slope": round(beta2, 4),
        "se_beta1": round(se_beta1, 4),
        "se_beta2": round(se_beta2, 4),
        "t_stat": round(t_beta1, 4),
        "df": df,
        "p_two_sided": round(t_two_sided_pvalue(t_beta1, df), 6),
        "ci95_low": round(beta1 - tc * se_beta1, 4),
        "ci95_high": round(beta1 + tc * se_beta1, 4),
        "rmse": round(rmse, 4),
        "r_squared": round(r2, 4),
        "partial_eta2": round(partial_eta2, 4),
        "slope_mindful": round(slope1, 4),
        "slope_waitlist": round(slope0, 4),
        "interaction_p": round(p_int, 4),
    }


def simple_ols(xs, ys):
    n = len(xs)
    xb, yb = mean(xs), mean(ys)
    sxx = sum((x - xb) ** 2 for x in xs)
    sxy = sum((x - xb) * (y - yb) for x, y in zip(xs, ys))
    b1 = sxy / sxx
    b0 = yb - b1 * xb
    df = n - 2
    sse = sum((y - (b0 + b1 * x)) ** 2 for x, y in zip(xs, ys))
    sst = sum((y - yb) ** 2 for y in ys)
    mse = sse / df
    se_b1 = math.sqrt(mse / sxx)
    t_val = b1 / se_b1
    tc = t_crit_95(df)
    return {
        "n": n,
        "intercept": round(b0, 4),
        "slope_per_day": round(b1, 4),
        "se_slope": round(se_b1, 4),
        "t_stat": round(t_val, 4),
        "p_two_sided": round(t_two_sided_pvalue(t_val, df), 6),
        "ci95_low": round(b1 - tc * se_b1, 4),
        "ci95_high": round(b1 + tc * se_b1, 4),
        "r_squared": round(1.0 - sse / sst, 4),
    }


def bootstrap_ancova_ci(g_list, x_list, y_list, n_boot=2000, seed=5509):
    rng = random.Random(seed)
    idx1 = [i for i, g in enumerate(g_list) if g == 1]
    idx0 = [i for i, g in enumerate(g_list) if g == 0]
    ests = []
    for _ in range(n_boot):
        s1 = [rng.choice(idx1) for _ in idx1]
        s0 = [rng.choice(idx0) for _ in idx0]
        all_idx = s1 + s0
        g_b = [g_list[i] for i in all_idx]
        x_b = [x_list[i] for i in all_idx]
        y_b = [y_list[i] for i in all_idx]
        res = ols_ancova(g_b, x_b, y_b)
        ests.append(res["beta1_group_effect"])
    ests.sort()
    lo = ests[int(0.025 * n_boot)]
    hi = ests[int(0.975 * n_boot)]
    return round(lo, 4), round(hi, 4)


def run_analysis(data_dir: Path = HERE, out_dir: Path = None):
    if out_dir is None:
        out_dir = data_dir / "expected"
    out_dir.mkdir(parents=True, exist_ok=True)

    with (data_dir / "screening_log.csv").open("r", encoding="utf-8-sig") as f:
        scr_rows = list(csv.DictReader(f))
    with (data_dir / "trial_participants.csv").open("r", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    with (data_dir / "pss10_item_audit.csv").open("r", encoding="utf-8-sig") as f:
        audit_rows = list(csv.DictReader(f))

    # 0. CONSORT flow counts
    n_screened = len(scr_rows)
    n_excluded = sum(1 for r in scr_rows if int(r["eligible"]) == 0)
    n_randomized = len(rows)
    mindful_all = [r for r in rows if r["group"] == "Mindful"]
    waitlist_all = [r for r in rows if r["group"] == "Waitlist"]
    cc_rows = [r for r in rows if int(r["followup_complete"]) == 1]
    pp_rows = [r for r in rows if int(r["per_protocol"]) == 1]

    # Item reverse-scoring audit check
    mis_scored_count = sum(1 for r in audit_rows if int(r["wrong_unreversed_sum"]) != int(r["correct_pss_pre"]))
    avg_abs_item_error = mean([abs(int(r["wrong_unreversed_sum"]) - int(r["correct_pss_pre"])) for r in audit_rows])

    # 1. Naive single-group pre-post trap (Mindful completers vs Waitlist completers)
    m_cc = [r for r in cc_rows if r["group"] == "Mindful"]
    w_cc = [r for r in cc_rows if r["group"] == "Waitlist"]
    paired_mindful = paired_t([float(r["pss_pre"]) for r in m_cc], [float(r["pss_post"]) for r in m_cc])
    paired_waitlist = paired_t([float(r["pss_pre"]) for r in w_cc], [float(r["pss_post"]) for r in w_cc])

    # 2. Unadjusted comparisons on Complete Cases (n = 58)
    unadj_post_t = two_sample_t(
        [float(r["pss_post"]) for r in m_cc],
        [float(r["pss_post"]) for r in w_cc]
    )
    did_change_t = two_sample_t(
        [float(r["pss_post"]) - float(r["pss_pre"]) for r in m_cc],
        [float(r["pss_post"]) - float(r["pss_pre"]) for r in w_cc]
    )

    # 3. Primary Analysis: Complete-Case ANCOVA (n = 58) + Nonparametric Bootstrap CI
    g_cc = [int(r["group_code"]) for r in cc_rows]
    x_cc = [float(r["pss_pre"]) for r in cc_rows]
    y_cc = [float(r["pss_post"]) for r in cc_rows]
    ancova_cc = ols_ancova(g_cc, x_cc, y_cc)
    boot_lo, boot_hi = bootstrap_ancova_ci(g_cc, x_cc, y_cc)
    ancova_cc["bootstrap_ci95_low"] = boot_lo
    ancova_cc["bootstrap_ci95_high"] = boot_hi
    se_reduction_pct = round((1.0 - ancova_cc["se_beta1"] / unadj_post_t["se"]) * 100.0, 2)
    ancova_cc["se_reduction_vs_unadjusted_pct"] = se_reduction_pct

    # 4. Intention-to-Treat (ITT, N = 64):
    #    4a) Conservative BOCF (Baseline Observation Carried Forward: dropout Y_post = Y_pre, i.e., 0 improvement)
    g_itt = [int(r["group_code"]) for r in rows]
    x_itt = [float(r["pss_pre"]) for r in rows]
    y_itt_bocf = [
        float(r["pss_post"]) if int(r["followup_complete"]) == 1 else float(r["pss_pre"])
        for r in rows
    ]
    ancova_itt_bocf = ols_ancova(g_itt, x_itt, y_itt_bocf)

    #    4b) Control-Reference Regression Imputation (Jump-to-Reference: dropouts imputed using Waitlist slope/intercept)
    xb0 = ancova_cc["x_bar_waitlist"]
    yb0 = ancova_cc["raw_post_waitlist"]
    b_w = ancova_cc["slope_waitlist"]
    y_itt_j2r = [
        float(r["pss_post"]) if int(r["followup_complete"]) == 1 else (yb0 + b_w * (float(r["pss_pre"]) - xb0))
        for r in rows
    ]
    ancova_itt_j2r = ols_ancova(g_itt, x_itt, y_itt_j2r)

    # 5. Per-Protocol (PP, n = 51: Mindful >=10 days vs Waitlist completers) -> demonstrates adherence inflation!
    ancova_pp = ols_ancova(
        [int(r["group_code"]) for r in pp_rows],
        [float(r["pss_pre"]) for r in pp_rows],
        [float(r["pss_post"]) for r in pp_rows],
    )

    # 6. Secondary Endpoints: Burnout-VAS ANCOVA & Wearable HRV-RMSSD (All CC vs S1-SQI Filtered!)
    ancova_burnout = ols_ancova(
        g_cc,
        [float(r["burnout_pre"]) for r in cc_rows],
        [float(r["burnout_post"]) for r in cc_rows],
    )
    ancova_hrv_unfiltered = ols_ancova(
        g_cc,
        [float(r["hrv_rmssd_pre"]) for r in cc_rows],
        [float(r["hrv_rmssd_post"]) for r in cc_rows],
    )
    sqi_rows = [r for r in cc_rows if int(r["sqi_pass"]) == 1]
    ancova_hrv_sqi_clean = ols_ancova(
        [int(r["group_code"]) for r in sqi_rows],
        [float(r["hrv_rmssd_pre"]) for r in sqi_rows],
        [float(r["hrv_rmssd_post"]) for r in sqi_rows],
    )

    # 7. Dose-Response within Mindful completers (change in PSS-10 vs objective completed_days)
    dose_ols = simple_ols(
        [float(r["completed_days"]) for r in m_cc],
        [float(r["pss_post"]) - float(r["pss_pre"]) for r in m_cc],
    )

    summary = {
        "consort": {
            "screened": n_screened,
            "excluded": n_excluded,
            "randomized": n_randomized,
            "mindful_allocated": len(mindful_all),
            "waitlist_allocated": len(waitlist_all),
            "mindful_completers": len(m_cc),
            "waitlist_completers": len(w_cc),
            "complete_case_n": len(cc_rows),
            "mindful_per_protocol": sum(1 for r in pp_rows if r["group"] == "Mindful"),
            "per_protocol_n": len(pp_rows),
            "hrv_sqi_clean_n": len(sqi_rows),
        },
        "item_reverse_audit": {
            "mis_scored_participants_if_unreversed": mis_scored_count,
            "mean_abs_score_error": round(avg_abs_item_error, 2),
        },
        "naive_pre_post": {
            "mindful": paired_mindful,
            "waitlist": paired_waitlist,
        },
        "unadjusted_post_t": unadj_post_t,
        "did_change_t": did_change_t,
        "primary_ancova_cc": ancova_cc,
        "itt_bocf_ancova": ancova_itt_bocf,
        "itt_j2r_ancova": ancova_itt_j2r,
        "per_protocol_ancova": ancova_pp,
        "secondary_burnout_ancova": ancova_burnout,
        "secondary_hrv_unfiltered": ancova_hrv_unfiltered,
        "secondary_hrv_sqi_clean": ancova_hrv_sqi_clean,
        "dose_response_mindful": dose_ols,
    }

    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # Write tidy comparison CSV table for manuscript Table 2
    comp_rows = [
        {
            "analysis_name": "單組前後測配對t檢定(僅看正念組-含時間與回歸平均偏誤)",
            "sample_n": f"28 (單組)",
            "estimate_pss10": paired_mindful["mean_change"],
            "se": paired_mindful["se_change"],
            "ci95": f"[{paired_mindful['ci95_low']:.2f}, {paired_mindful['ci95_high']:.2f}]",
            "p_value": f"{paired_mindful['p_two_sided']:.4f}",
            "interpretation": "高估療效！忽略等候組亦自然下降 " + f"{abs(paired_waitlist['mean_change']):.2f} 分",
        },
        {
            "analysis_name": "未校正兩組後測獨立t檢定(Unadjusted Post-test)",
            "sample_n": f"{unadj_post_t['n_mindful']}+{unadj_post_t['n_waitlist']}=58",
            "estimate_pss10": unadj_post_t["diff"],
            "se": unadj_post_t["se"],
            "ci95": f"[{unadj_post_t['ci95_low']:.2f}, {unadj_post_t['ci95_high']:.2f}]",
            "p_value": f"{unadj_post_t['p_two_sided']:.4f}",
            "interpretation": "未扣除基線個體差異，標準誤較大、信賴區間較寬",
        },
        {
            "analysis_name": "兩組前後差值t檢定(Change-Score / DiD, 假設斜率=1)",
            "sample_n": "28+30=58",
            "estimate_pss10": did_change_t["diff"],
            "se": did_change_t["se"],
            "ci95": f"[{did_change_t['ci95_low']:.2f}, {did_change_t['ci95_high']:.2f}]",
            "p_value": f"{did_change_t['p_two_sided']:.4f}",
            "interpretation": "扣除等候組自然回落，但未最佳化回歸平均斜率(β2≠1)",
        },
        {
            "analysis_name": "主分析：完整個案共變數分析(Complete-Case ANCOVA)",
            "sample_n": "28+30=58",
            "estimate_pss10": ancova_cc["beta1_group_effect"],
            "se": ancova_cc["se_beta1"],
            "ci95": f"[{ancova_cc['ci95_low']:.2f}, {ancova_cc['ci95_high']:.2f}]",
            "p_value": f"{ancova_cc['p_two_sided']:.4f}",
            "interpretation": f"校正基線斜率 β2={ancova_cc['beta2_baseline_slope']:.2f}，標準誤縮小 {se_reduction_pct:.1f}%",
        },
        {
            "analysis_name": "敏感度1：意向分析-基線結轉(ITT-BOCF, 全隨機樣本)",
            "sample_n": "32+32=64",
            "estimate_pss10": ancova_itt_bocf["beta1_group_effect"],
            "se": ancova_itt_bocf["se_beta1"],
            "ci95": f"[{ancova_itt_bocf['ci95_low']:.2f}, {ancova_itt_bocf['ci95_high']:.2f}]",
            "p_value": f"{ancova_itt_bocf['p_two_sided']:.4f}",
            "interpretation": "失訪6人保守視為零改善，療效仍維持統計顯著",
        },
        {
            "analysis_name": "敏感度2：意向分析-對照組參考插補(ITT Jump-to-Reference)",
            "sample_n": "32+32=64",
            "estimate_pss10": ancova_itt_j2r["beta1_group_effect"],
            "se": ancova_itt_j2r["se_beta1"],
            "ci95": f"[{ancova_itt_j2r['ci95_low']:.2f}, {ancova_itt_j2r['ci95_high']:.2f}]",
            "p_value": f"{ancova_itt_j2r['p_two_sided']:.4f}",
            "interpretation": "失訪者按等候對照組軌跡插補，結果與主分析高度一致",
        },
        {
            "analysis_name": "依從協定分析(Per-Protocol, 僅納完課>=10天者)",
            "sample_n": f"{summary['consort']['mindful_per_protocol']}+30={len(pp_rows)}",
            "estimate_pss10": ancova_pp["beta1_group_effect"],
            "se": ancova_pp["se_beta1"],
            "ci95": f"[{ancova_pp['ci95_low']:.2f}, {ancova_pp['ci95_high']:.2f}]",
            "p_value": f"{ancova_pp['p_two_sided']:.4f}",
            "interpretation": "只留高動機完課者會放大效果，僅可列補充不可取代ITT",
        },
    ]
    with (out_dir / "model_comparison.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(comp_rows[0].keys()))
        w.writeheader()
        w.writerows(comp_rows)

    return summary


if __name__ == "__main__":
    res = run_analysis()
    print(json.dumps(res, ensure_ascii=False, indent=2))
