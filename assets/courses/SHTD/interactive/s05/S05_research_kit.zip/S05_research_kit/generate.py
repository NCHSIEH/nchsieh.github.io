# -*- coding: utf-8 -*-
"""S5 正念冥想減壓等候名單對照試驗與 ANCOVA 分析 — 決定性合成臨床試驗資料產生器 (seed=5509)"""
from pathlib import Path
import csv
import math
import random

SEED = 5509
HERE = Path(__file__).resolve().parent


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def generate_all(out_dir: Path = HERE):
    rng = random.Random(SEED)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Screening log (N_screen = 72 -> 8 excluded -> 64 randomized)
    screening_rows = []
    excl_reasons = [
        "近1個月已規律使用冥想App(>=3次/週)",
        "近1個月已規律使用冥想App(>=3次/週)",
        "目前接受結構化心理諮商或抗焦慮藥物調整中",
        "目前接受結構化心理諮商或抗焦慮藥物調整中",
        "心律不整病史影響穿戴式HRV判讀",
        "配戴心律調節器不納入HRV次要指標評估",
        "無法配合14天前後測時間窗拒絕隨機分派",
        "個人因素撤回知情同意未進入隨機分派",
    ]
    excl_indices = {5, 13, 22, 31, 40, 49, 58, 67}
    excl_ptr = 0
    rand_idx = 0

    participants = []
    # Block randomization (block size 4) within 2 strata:
    # Stratum 1: student_intern (32 randomized -> 16 Mindful, 16 Waitlist)
    # Stratum 2: junior_nurse   (32 randomized -> 16 Mindful, 16 Waitlist)
    blocks = []
    for stratum in ["護理實習生", "新進臨床護理師"]:
        for b in range(8):
            arm_block = ["Mindful", "Mindful", "Waitlist", "Waitlist"]
            rng.shuffle(arm_block)
            for arm in arm_block:
                blocks.append((stratum, arm, f"B{1 if stratum=='護理實習生' else 2}{b+1:02d}"))

    for s_id in range(1, 73):
        scr_code = f"SCR-{s_id:03d}"
        if s_id in excl_indices:
            reason = excl_reasons[excl_ptr]
            excl_ptr += 1
            screening_rows.append({
                "screen_id": scr_code,
                "eligible": 0,
                "randomized": 0,
                "participant_id": "",
                "exclusion_reason": reason,
            })
            continue

        stratum, arm, block_id = blocks[rand_idx]
        rand_idx += 1
        pid = f"P{rand_idx:03d}"
        screening_rows.append({
            "screen_id": scr_code,
            "eligible": 1,
            "randomized": 1,
            "participant_id": pid,
            "exclusion_reason": "",
        })

        age = rng.randint(20, 23) if stratum == "護理實習生" else rng.randint(23, 29)
        night_shifts_past2w = rng.randint(1, 3) if stratum == "護理實習生" else rng.randint(3, 6)

        # Latent baseline stress trait
        base_stress = 22.8 + (1.4 if stratum == "新進臨床護理師" else 0.0) + 0.35 * (night_shifts_past2w - 3) + rng.gauss(0, 4.2)
        pss_pre = int(round(clamp(base_stress, 12, 34)))

        # Construct 10 item scores (0-4) summing to pss_pre, demonstrating reverse-scored items 4,5,7,8
        # Forward items: 1,2,3,6,9,10 (higher=more stress); Reverse items raw: 4,5,7,8 (higher=more coping -> reversed = 4 - raw)
        item_revs = [max(0, min(4, int(round(pss_pre / 10.0 + rng.gauss(0, 0.7))))) for _ in range(10)]
        diff = pss_pre - sum(item_revs)
        step = 1 if diff > 0 else -1
        k_guard = 0
        while diff != 0 and k_guard < 200:
            idx = rng.randrange(10)
            if 0 <= item_revs[idx] + step <= 4:
                item_revs[idx] += step
                diff -= step
            k_guard += 1
        pss_pre = sum(item_revs)
        # Raw item values before reversing items 4,5,7,8 (0-indexed: 3,4,6,7)
        raw_items_pre = [
            (4 - v) if idx in (3, 4, 6, 7) else v
            for idx, v in enumerate(item_revs)
        ]

        # Baseline burnout VAS (0-100) and wearable seated HRV-RMSSD (ms) & HR (bpm)
        burnout_pre = round(clamp(32.0 + 1.65 * pss_pre + rng.gauss(0, 6.5), 25.0, 92.0), 1)
        hrv_pre = round(clamp(58.0 - 0.85 * (pss_pre - 18) + rng.gauss(0, 6.2), 18.0, 78.0), 1)
        hr_pre = round(clamp(68.0 + 0.52 * (pss_pre - 18) + rng.gauss(0, 4.5), 56.0, 96.0), 1)

        # App objective adherence during 14-day window
        if arm == "Mindful":
            # Realistic bimodal/skewed adherence: ~75% adherent (>=10 days), ~25% low adherence
            if rng.random() < 0.74:
                completed_days = rng.randint(10, 14)
            else:
                completed_days = rng.randint(2, 8)
            total_minutes = round(completed_days * rng.uniform(9.2, 10.6), 1)
        else:
            completed_days = 0
            total_minutes = 0.0

        participants.append({
            "participant_id": pid,
            "block_id": block_id,
            "stratum": stratum,
            "group": arm,
            "group_code": 1 if arm == "Mindful" else 0,
            "age": age,
            "night_shifts_2w": night_shifts_past2w,
            "pss_pre": pss_pre,
            "burnout_pre": burnout_pre,
            "hrv_rmssd_pre": hrv_pre,
            "resting_hr_pre": hr_pre,
            "completed_days": completed_days,
            "app_minutes": total_minutes,
            "_raw_items_pre": raw_items_pre,
        })

    # Assign deterministic attrition: 4 dropouts in Mindful (2 low-adherence + 2 heavy night-shift), 2 in Waitlist
    mindful_candidates = [p for p in participants if p["group"] == "Mindful"]
    mindful_candidates.sort(key=lambda x: (x["completed_days"], -x["night_shifts_2w"], x["participant_id"]))
    dropout_ids = {mindful_candidates[idx]["participant_id"] for idx in (0, 2, 10, 16)}

    waitlist_candidates = [p for p in participants if p["group"] == "Waitlist"]
    waitlist_candidates.sort(key=lambda x: (-x["night_shifts_2w"], -x["pss_pre"], x["participant_id"]))
    dropout_ids.update(p["participant_id"] for p in waitlist_candidates[:2])

    # Assign S1-style wearable SQI quality flags on post-test (6 participants measured right after coffee/walking -> sqi_pass=0)
    non_dropouts = [p["participant_id"] for p in participants if p["participant_id"] not in dropout_ids]
    sqi_fail_ids = set(non_dropouts[3::10][:6])

    item_audit_rows = []
    for p in participants:
        pid = p["participant_id"]
        pss_pre = p["pss_pre"]
        arm = p["group"]
        days = p["completed_days"]
        is_drop = pid in dropout_ids

        # True data-generating model:
        # 1) Natural exam/shift relief + regression to mean:
        #    E[Y_post | Waitlist] = 21.2 + 0.68 * (pss_pre - 23.0)  (so mean drops ~1.8 pts even in Waitlist!)
        # 2) Dose-dependent mindfulness effect:
        #    -0.31 pts per completed day (~ -3.7 pts overall in Mindful completers, ~ -4.1 pts in >=10d completers)
        dose_effect = -0.32 * days if arm == "Mindful" else 0.0
        expected_post = (pss_pre - 1.75) - 0.30 * (pss_pre - 23.5) + dose_effect
        pss_post_latent = int(round(clamp(expected_post + rng.gauss(0, 2.35), 6, 35)))

        burnout_post_latent = round(clamp(
            p["burnout_pre"] - 3.2 - 0.22 * (p["burnout_pre"] - 70.0)
            + (-0.68 * days if arm == "Mindful" else 0.0) + rng.gauss(0, 4.8),
            15.0, 92.0
        ), 1)

        # True HRV improvement + S1 artifact injection when sqi_pass == 0
        sqi_pass = 0 if (not is_drop and pid in sqi_fail_ids) else ("" if is_drop else 1)
        hrv_true_post = clamp(
            p["hrv_rmssd_pre"] + 0.8 + (0.48 * days if arm == "Mindful" else 0.0) + rng.gauss(0, 3.6),
            18.0, 88.0
        )
        if sqi_pass == 0:
            # Motion / photoplethysmography artifact inflates RMSSD wildly (+26 to +42 ms)
            hrv_measured_post = round(hrv_true_post + rng.uniform(26.0, 41.0), 1)
            sqi_note = "運動後未靜坐滿5分鐘或PPG光學雜訊>15%"
        elif sqi_pass == 1:
            hrv_measured_post = round(hrv_true_post, 1)
            sqi_note = "清晨靜坐5分鐘標準量測通過"
        else:
            hrv_measured_post = ""
            sqi_note = "未完成後測"

        hr_post_val = "" if is_drop else round(clamp(
            p["resting_hr_pre"] - 0.6 + (-0.24 * days if arm == "Mindful" else 0.0) + rng.gauss(0, 2.8),
            54.0, 95.0
        ), 1)

        p["followup_complete"] = 0 if is_drop else 1
        p["per_protocol"] = 1 if (not is_drop and ((arm == "Mindful" and days >= 10) or arm == "Waitlist")) else 0
        p["pss_post"] = "" if is_drop else pss_post_latent
        p["burnout_post"] = "" if is_drop else burnout_post_latent
        p["hrv_rmssd_post"] = hrv_measured_post
        p["resting_hr_post"] = hr_post_val
        p["sqi_pass"] = sqi_pass
        p["sqi_note"] = sqi_note

        raw_pre = p.pop("_raw_items_pre")
        naive_wrong_sum = sum(raw_pre)  # Trap if student forgets to reverse items 4,5,7,8!
        row_audit = {
            "participant_id": pid,
            "group": arm,
        }
        for j, v in enumerate(raw_pre, 1):
            row_audit[f"q{j}_raw"] = v
        row_audit["wrong_unreversed_sum"] = naive_wrong_sum
        row_audit["correct_pss_pre"] = pss_pre
        item_audit_rows.append(row_audit)

    # Write CSV files
    with (out_dir / "screening_log.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(screening_rows[0].keys()))
        w.writeheader()
        w.writerows(screening_rows)

    part_fields = [
        "participant_id", "block_id", "stratum", "group", "group_code",
        "age", "night_shifts_2w", "completed_days", "app_minutes",
        "followup_complete", "per_protocol",
        "pss_pre", "pss_post", "burnout_pre", "burnout_post",
        "hrv_rmssd_pre", "hrv_rmssd_post", "resting_hr_pre", "resting_hr_post",
        "sqi_pass", "sqi_note"
    ]
    with (out_dir / "trial_participants.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=part_fields)
        w.writeheader()
        w.writerows(participants)

    with (out_dir / "pss10_item_audit.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(item_audit_rows[0].keys()))
        w.writeheader()
        w.writerows(item_audit_rows)

    return participants


if __name__ == "__main__":
    rows = generate_all()
    print(f"Generated {len(rows)} randomized participants in {HERE}")
