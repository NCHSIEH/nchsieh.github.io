# -*- coding: utf-8 -*-
"""S5 工作包自動驗算腳本 (check.py)：一鍵重現資料產生與 ANCOVA / ITT 數值核對"""
from pathlib import Path
import json
import sys
import tempfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import generate
import analyze


def main():
    expected_json = HERE / "expected" / "summary.json"
    if not expected_json.exists():
        print("[INIT] Creating baseline expected outputs...")
        generate.generate_all(HERE)
        analyze.run_analysis(HERE, HERE / "expected")

    gold = json.loads(expected_json.read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        generate.generate_all(tmp_path)
        fresh = analyze.run_analysis(tmp_path, tmp_path / "out")

    assert gold == fresh, f"Mismatch!\nExpected: {gold}\nGot: {fresh}"
    cc = fresh["primary_ancova_cc"]
    itt = fresh["itt_bocf_ancova"]
    pp = fresh["per_protocol_ancova"]
    print("============================================================")
    print("PASS! S05 正念冥想減壓試驗與 ANCOVA 研究工作包全數驗算相符")
    print(f"  CONSORT: 篩選 {fresh['consort']['screened']} -> 隨機 {fresh['consort']['randomized']} -> 完成後測 {fresh['consort']['complete_case_n']}")
    print(f"  主分析 ANCOVA (n=58): β1 = {cc['beta1_group_effect']:.2f} 分 (95% CI [{cc['ci95_low']:.2f}, {cc['ci95_high']:.2f}], p={cc['p_two_sided']:.4f})")
    print(f"  保守意向分析 ITT-BOCF (N=64): β1 = {itt['beta1_group_effect']:.2f} 分 (p={itt['p_two_sided']:.4f})")
    print(f"  依從協定 PP (>=10天, n={fresh['consort']['per_protocol_n']}): β1 = {pp['beta1_group_effect']:.2f} 分")
    print("============================================================")


if __name__ == "__main__":
    main()
